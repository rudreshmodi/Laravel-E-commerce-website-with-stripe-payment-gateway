<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class Subcategory extends Model
{
    use HasFactory, SoftDeletes; // Enable SoftDeletes

    // Fillable fields for mass assignment
    protected $fillable = ['name', 'category_id', 'description', 'image'];

    // Relationship: A subcategory belongs to a category
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    // Relationship: A subcategory has many products
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    public function combos()
    {
        return $this->hasMany(Combo::class);
    }

    /**
     * Get the name of the related category.
     *
     * @return string
     */
    public function getCategoryNameAttribute()
    {
        return $this->category ? $this->category->name : 'No category';
    }

    // Boot method to handle cascading soft-deletes and restorations
    protected static function boot()
    {
        parent::boot();

        // Automatically handle cascading deletes
        static::deleting(function ($subcategory) {
            if ($subcategory->isForceDeleting()) {
                // Hard delete related products when the subcategory is permanently deleted
                $subcategory->products()->forceDelete();
            } else {
                // Soft delete related products when the subcategory is soft deleted
                $subcategory->products()->delete();
            }
        });

        // Automatically handle cascading restores
        static::restoring(function ($subcategory) {
            // Restore related products when the subcategory is restored
            $subcategory->products()->withTrashed()->restore();
        });
    }

    // Set the image attribute with size validation
    public function setImageAttribute($value)
    {
        // If a file is being uploaded
        if ($value instanceof \Illuminate\Http\UploadedFile) {
            // Check if the file size is greater than 10MB (10485760 bytes)
            if ($value->getSize() > 10485760) {
                throw new ValidationException('The image size must be less than 10MB.');
            }

            // Optionally, store the file and get the path if the validation passes
            $this->attributes['image'] = $value->store('images'); // or use your own storage path
        } else {
            // If there's no image, just assign it as is
            $this->attributes['image'] = $value;
        }
    }
}
