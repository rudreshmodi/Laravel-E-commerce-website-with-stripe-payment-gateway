<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Wishlist extends Model
{
    use HasFactory;

    // The attributes that are mass assignable
    protected $fillable = ['user_id', 'products'];

    // Cast the products attribute to an array
    protected $casts = [
        'products' => 'array',
    ];

    /**
     * Get the user that owns the wishlist.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
