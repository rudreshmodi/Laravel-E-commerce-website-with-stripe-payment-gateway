<?php

namespace App\Models;

use App\Mail\AccountDeletionNotice;
use App\Notifications\CustomEmailVerificationNotification;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes; // Import SoftDeletes
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class User extends Authenticatable implements MustVerifyEmail
{
    use Notifiable, HasFactory, Notifiable, SoftDeletes; // Use SoftDeletes trait

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'mobile_number',
        'password',
        'role',
        'email_verification_token',
        'otp',
        'otp_verified_at',
        'deleted_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'otp_verified_at' => 'datetime', // Automatically cast this field to datetime
        'deleted_at' => 'datetime', // Cast 'deleted_at' as a datetime instance
        'password' => 'hashed', // Automatically hashes the password attribute
    ];

    /**
     * Generate email verification token and OTP when a user registers.
     */
    protected static function booted()
    {
        static::creating(function ($user) {
            // Generate a unique token for email verification
            $user->email_verification_token = Str::random(60); // Use a random string for the email verification token
            $user->otp = rand(100000, 999999); // Generate a 6-digit OTP for phone verification
        });
    }

    /**
     * Override the method to send the email verification notification.
     *
     * @return void
     */
    public function sendEmailVerificationNotification()
    {
        // Send the custom email verification notification
        $this->notify(new CustomEmailVerificationNotification($this));
    }

    /**
     * Send OTP verification code via SMS.
     * (You can integrate this with Twilio or any other SMS provider)
     */
    public function sendOtpSms($otp)
    {
        // Example: Use Twilio or any other SMS service to send the OTP
        $sid = env('TWILIO_SID');
        $token = env('TWILIO_AUTH_TOKEN');
        $twilioNumber = env('TWILIO_PHONE_NUMBER');

        $client = new \Twilio\Rest\Client($sid, $token);

        try {
            $client->messages->create(
                $this->mobile_number, // User's phone number
                [
                    'from' => $twilioNumber, // Your Twilio phone number
                    'body' => "Your OTP code is: $otp" // The OTP message
                ]
            );
        } catch (\Exception $e) {
            // Handle errors (e.g., invalid phone number)
            Log::error("Failed to send OTP: " . $e->getMessage());
        }
    }

    /**
     * Mark the user's phone number as verified.
     *
     * @return void
     */
    public function verifyPhone()
    {
        $this->otp_verified_at = now(); // Set OTP verification timestamp
        $this->save();
    }

    /**
     * Check if the user's phone number is verified.
     *
     * @return bool
     */
    public function isPhoneVerified()
    {
        return !is_null($this->otp_verified_at); // Returns true if phone number is verified
    }

    /**
     * Mark the user's account for deletion.
     *
     * @return void
     */
    public function markForDeletion()
    {
        // Set the deletion timestamp to 24 hours from now
        $this->deleted_at = now()->addDay(); // 24 hours from now
        $this->save();

        // Send an email notification about account deletion
        Mail::to($this->email)->send(new AccountDeletionNotice($this));
    }


    /**
     * Check if the user's account is marked for deletion.
     *
     * @return bool
     */
    public function isMarkedForDeletion()
    {
        return !is_null($this->deleted_at) && $this->deleted_at->isFuture();
    }

    /**
     * Perform the soft delete of the user account.
     * This will set the `deleted_at` field and remove the user from active queries.
     *
     * @return void
     */
    public function softDeleteAccount()
    {
        // Soft delete by using the built-in soft delete feature
        $this->delete(); // This will set the `deleted_at` field in the database
    }

    /**
     * Perform a permanent delete of the user account.
     * This will remove the user from the database completely.
     *
     * @return void
     */
    public function forceDeleteAccount()
    {
        // Permanently delete the user record from the database
        $this->forceDelete();
    }
}
