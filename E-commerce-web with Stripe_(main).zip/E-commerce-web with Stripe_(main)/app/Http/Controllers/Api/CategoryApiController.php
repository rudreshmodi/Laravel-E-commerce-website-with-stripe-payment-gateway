<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CategoryApiController extends Controller
{
    /**
     * Display a listing of the categories.
     */
    public function index(Request $request)
    {
        // dd("Sdf");
        // Start with the base query to get categories
        $query = Category::withoutTrashed();

        // Apply the filter for category name search if provided
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Get the paginated result
        $categories = $query->paginate(10);

        return response()->json($categories);
    }

    /**
     * Store a newly created category in storage.
     */
    public function store(Request $request)
    {
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('category_images', 'public');
        }

        $category = Category::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'image' => isset($imagePath) ? $imagePath : null
        ]);

        return response()->json([
            'message' => 'Category created successfully!',
            'category' => $category
        ], 201);
    }



    /**
     * Display the specified category.
     */
    public function show(Category $category)
    {
        // Fetch products related to the category, including soft-deleted ones, with pagination
        $products = $category->products()->withTrashed()->paginate(10); // Adjust pagination as needed

        // If no products are found, return a custom message with a 404 status
        if ($products->isEmpty()) {
            response()->json(['message' => 'No products found for this category.'], 404);
        }

        // Fetch subcategories related to the category, including soft-deleted ones, with pagination
        $subcategories = $category->subcategories()->withTrashed()->paginate(10); // Added pagination

        // If no subcategories are found, return a custom message with a 404 status
        if ($subcategories->isEmpty()) {
            response()->json(['message' => 'No subcategories found for this category.'], 404);
        }

        // Return a JSON response with the category, products, and subcategories
        return response()->json([
            'category' => $category,
            'products' => $products,
            'subcategories' => $subcategories
        ]);
    }



    /**
     * Show the form for editing the specified category.
     */
    public function edit(Category $category)
    {
        return response()->json($category);
    }

    /**
     * Update the specified category in storage.
     */
    public function update(Request $request, Category $category)
    {
        // Handle the image upload if an image is provided
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($category->image && Storage::exists('public/' . $category->image)) {
                Storage::delete('public/' . $category->image);
            }

            // Store new image and add it to the request data
            $imagePath = $request->file('image')->store('category_images', 'public');
            $request->merge(['image' => $imagePath]); // Merge the image path to the request data
        }

        // Update the category with the request data
        $categoryUpdated = $category->update($request->only(['name', 'description', 'image']));

        // Check if update was successful
        if ($categoryUpdated) {
            return response()->json([
                'message' => 'Category updated successfully!',
                'category' => $category
            ]);
        } else {
            return response()->json([
                'message' => 'Failed to update category.'
            ], 500); // Return error message with a 500 status if update fails
        }
    }

    /**
     * Soft delete the category and its products.
     */
    public function destroy(Category $category)
    {
        // Soft delete related products and category
        $category->products()->delete();  // Soft delete products
        $category->delete(); // Soft delete the category

        return response()->json([
            'message' => 'Category and its products deleted successfully!'
        ]);
    }

    /**
     * Restore a soft-deleted category and its products.
     */
    public function restore($id)
    {
        // Find the category including soft-deleted ones
        $category = Category::withTrashed()->findOrFail($id);

        // Restore the category and its products
        $category->restore();
        $category->products()->withTrashed()->restore(); // Restore soft-deleted products

        return response()->json([
            'message' => 'Category and its products restored successfully!',
            'category' => $category
        ]);
    }

    /**
     * Display all products belonging to the specified category.
     */
    public function viewProducts(Category $category)
    {
        $products = $category->products()->withTrashed()->paginate(10);

        if ($products->isEmpty()) {
            return response()->json(['message' => 'No products found for this category.'], 404);
        }

        return response()->json([
            'category' => $category,
            'products' => $products
        ]);
    }

    /**
     * Display all subcategories belonging to the specified category.
     */
    public function viewSubcategories(Category $category)
    {
        $subcategories = $category->subcategories()->withTrashed()->paginate(10);

        if ($subcategories->isEmpty()) {
            return response()->json(['message' => 'No subcategories found for this category.'], 404);
        }

        return response()->json([
            'category' => $category,
            'subcategories' => $subcategories
        ]);
    }
}
