<?php

namespace App\Http\Controllers;

use App\Models\Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DeletedSubcategoryController extends Controller
{
    /**
     * Show the list of deleted categories.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to view deleted Subcategory.');
        }

        // Get all soft-deleted categories
        $deletedSubcategories = Subcategory::onlyTrashed()->get();

        return view('subcategories.deleted', compact('deletedSubcategories'));
    }

    /**
     * Restore the specified soft-deleted category.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to restore categories.');
        }

        // Find the soft-deleted category by its ID
        $subcategory = Subcategory::withTrashed()->findOrFail($id);

        // Restore the category
        $subcategory->restore();

        // Redirect back with success message
        return redirect()->route('subcategories.index')->with('success', 'Subcategory restored successfully!');
    }

    /**
     * Force delete a category permanently.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function forceDelete($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to permanently delete categories.');
        }

        // Find the soft-deleted category by its ID
        $subcategory = Subcategory::onlyTrashed()->findOrFail($id);

        // Force delete the category permanently
        $subcategory->forceDelete();

        // Redirect back with success message
        return redirect()->route('subcategories.index')->with('success', 'Subcategory permanently deleted.');
    }
}
