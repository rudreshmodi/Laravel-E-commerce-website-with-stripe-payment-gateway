<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class SubcategoryController extends Controller
{
    /**
     * Display a listing of all subcategories.
     */
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Start with the base query to get subcategories
        $query = Subcategory::withoutTrashed();

        // Apply the filter for subcategory name search if provided
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        // Get the paginated result
        $subcategories = $query->paginate(10);

        return view('subcategories.index', compact('subcategories'));
    }

    /**
     * Show the form for creating a new subcategory.
     */
    public function create()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $categories = Category::all();

        return view('subcategories.create', compact('categories'));
    }

    /**
     * Store a newly created subcategory in storage.
     */
    public function store(Request $request)
    {
        // Check if user is authenticated and has 'admin' role
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Validate the incoming request data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|integer',
            'description' => 'required|string|max:150',
            'image' => 'required|image|mimes:jpeg,png,jpg|max:10240', // Validate image file
        ]);

        // Store image if uploaded
        if ($request->hasFile('image')) {
            // Store the image in 'public/images' directory
            $validated['image'] = $request->file('image')->store('images', 'public');
        }

        // Create the subcategory with validated data
        Subcategory::create($validated);

        return redirect()->route('subcategories.index')->with('success', 'Subcategory created successfully.');
    }


    /**
     * Display the specified subcategory.
     */
    public function show($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $subcategory = Subcategory::findOrFail($id);

        return view('subcategories.show', compact('subcategory'));
    }

    /**
     * Show the form for editing a specific subcategory.
     */
    public function edit($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $subcategory = Subcategory::findOrFail($id);
        $categories = Category::all();
        return view('subcategories.edit', compact('subcategory', 'categories'));
    }

    /**
     * Update the specified subcategory in storage.
     */
    public function update(Request $request, $id)
    {
        // Check if user is authenticated and has 'admin' role
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Validate the incoming request data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|integer',
            'description' => 'required|string|max:150',
            'image' => 'nullable|image|mimes:jpeg,png,jpg|max:10240', // Validate image file (nullable)
        ]);

        // Find the subcategory by ID
        $subcategory = Subcategory::findOrFail($id);

        // If a new image was uploaded, process it
        if ($request->hasFile('image')) {
            // Delete the old image if it exists
            if ($subcategory->image && Storage::exists('public/' . $subcategory->image)) {
                Storage::delete('public/' . $subcategory->image);
            }

            // Store the new image in the 'images' folder
            $validated['image'] = $request->file('image')->store('images', 'public');
        }

        // Update the subcategory with the validated data
        $subcategory->update($validated);

        return redirect()->route('subcategories.index')->with('success', 'Subcategory updated successfully.');
    }

    /**
     * Soft delete the specified subcategory from storage.
     */
    public function destroy($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $subcategory = Subcategory::findOrFail($id);

        // Mark the image as deleted (soft-delete) by not physically deleting the file
        if ($subcategory->image && Storage::exists('public/' . $subcategory->image)) {
            // You could add a custom logic here to move the image to a "deleted" folder if required
            // Or you could simply set a flag in the database to mark it as deleted
            // For simplicity, we leave it in place and just ensure it doesn't get used
        }

        // Soft delete the subcategory
        $subcategory->delete();

        return redirect()->route('subcategories.index')->with('success', 'Subcategory deleted successfully.');
    }

    /**
     * Restore the specified soft-deleted subcategory and its image (if exists).
     */
    public function restore($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        $subcategory = Subcategory::withTrashed()->findOrFail($id);

        // Restore the subcategory
        $subcategory->restore();

        // If the subcategory had an image, restore or confirm its existence
        if ($subcategory->image && !Storage::exists('public/' . $subcategory->image)) {
            // You would need to restore the image file manually if it's not in place
            // For example, you might keep a backup of the images in a different folder.
            // Here, we are assuming the image already exists in the 'public/images' directory
            // and doesn't need to be restored separately, as Laravel doesn't handle "image restoration" natively.
        }

        session()->flash('success', 'Subcategory and its image restored successfully!');

        return redirect()->route('subcategories.index');
    }

    /**
     * Display all products belonging to the specified subcategory.
     */
    public function viewProducts($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }


        // Find the subcategory by ID
        $subcategory = Subcategory::findOrFail($id);

        // Fetch products related to the subcategory, including soft-deleted ones
        $products = $subcategory->products()->withTrashed()->paginate(10);

        if ($products->isEmpty()) {
            return back()->with('error', 'No products found for this subcategory.');
        }

        return view('subcategories.products', compact('subcategory', 'products'));
    }
}
