<?php

namespace App\Http\Controllers;

use App\Models\Coupon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CouponController extends Controller
{
    /**
     * Display a listing of the coupons.
     */
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $query = Coupon::query();

        // Apply search filter if provided
        if ($request->filled('search')) {
            $query->where('coupon_code', 'like', '%' . $request->search . '%');
        }

        $coupons = $query->paginate(10);

        return view('Coupon.index', compact('coupons'));
    }

    /**
     * Show the form for creating a new coupon.
     */
    public function create()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        return view('Coupon.create');
    }

    /**
     * Store a newly created coupon in storage.
     */
    public function store(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $request->validate([
            'coupon_code' => 'required|unique:coupons',
            'discount_value' => 'required|numeric',
            'type' => 'required|in:single,multiple',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'status' => 'required|boolean',
        ]);

        Coupon::create($request->all());

        return redirect()->route('Coupon.index')->with('success', 'Coupon created successfully.');
    }

    /**
     * Display the specified coupon.
     */
    public function show(Coupon $coupon)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        return view('Coupon.show', compact('coupon'));
    }

    /**
     * Show the form for editing the specified coupon.
     */
    public function edit(Coupon $coupon)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        return view('Coupon.edit', compact('coupon'));
    }

    /**
     * Update the specified coupon in storage.
     */
    public function update(Request $request, Coupon $coupon)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $request->validate([
            'coupon_code' => 'required|unique:coupons,coupon_code,' . $coupon->id,
            'discount_value' => 'required|numeric',
            'type' => 'required|in:single,multiple',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'status' => 'required|boolean',
        ]);

        $coupon->update($request->all());

        return redirect()->route('Coupon.index')->with('success', 'Coupon updated successfully.');
    }

    /**
     * Soft delete the specified coupon.
     */
    public function destroy(Coupon $coupon)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $coupon->delete();

        return redirect()->route('Coupon.index')->with('success', 'Coupon soft-deleted successfully.');
    }

    /**
     * Display a listing of soft-deleted coupons.
     */
    public function trashed(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $query = Coupon::onlyTrashed();

        if ($request->filled('search')) {
            $query->where('coupon_code', 'like', '%' . $request->search . '%');
        }

        $coupons = $query->paginate(10);

        return view('Coupon.trashed', compact('coupons'));
    }

    /**
     * Restore a soft-deleted coupon.
     */
    public function restore($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $coupon = Coupon::withTrashed()->findOrFail($id);
        $coupon->restore();

        return redirect()->route('Coupon.index')->with('success', 'Coupon restored successfully.');
    }

    /**
     * Permanently delete a coupon.
     */
    public function forceDelete($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $coupon = Coupon::withTrashed()->findOrFail($id);
        $coupon->forceDelete();

        return redirect()->route('Coupon.trashed')->with('success', 'Coupon permanently deleted.');
    }

    /**
     * Display active coupons with optional search.
     */
    public function viewActiveCoupons(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login');
        }

        $query = Coupon::where('status', true);

        if ($request->filled('search')) {
            $query->where('coupon_code', 'like', '%' . $request->search . '%');
        }

        $coupons = $query->paginate(10);

        return view('Coupon.active', compact('coupons'));
    }
}
