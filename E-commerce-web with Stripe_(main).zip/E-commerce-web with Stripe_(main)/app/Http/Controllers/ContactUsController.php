<?php

namespace App\Http\Controllers;

use App\Models\ContactUs;
use App\Models\Reply;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use App\Notifications\NewContactUsNotification;
use App\Notifications\ReplyToContactUsNotification;

class ContactUsController extends Controller
{
    // Show the inbox (list of messages)
    public function index()
    {
        // Fetch all contact submissions (both read and unread)
        $contactUsSubmissions = ContactUs::with('replies')->get();

        // Fetch the latest contact message along with its reply
        $latestMessage = ContactUs::with('replies')->latest()->first();

        return view('user.contact-us', compact('contactUsSubmissions', 'latestMessage'));
    }

    // Show the contact form
    public function create()
    {
        $latestMessage = ContactUs::with('replies')->latest()->first();
        $contactUsSubmissions = ContactUs::with('replies')->get();

        return view('user.contact-us', compact('contactUsSubmissions', 'latestMessage'));
    }

    // Handle the form submission
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string',
        ]);

        // Save the contact submission
        $contactUs = ContactUs::create([
            'name' => $request->name,
            'email' => $request->email,
            'message' => $request->message,
        ]);

        // Notify the admin
        Notification::route('mail', 'admin@example.com')
            ->notify(new NewContactUsNotification($contactUs));

        // Fetch the latest message with its reply (if any)
        $latestMessage = ContactUs::with('replies')->latest()->first();

        // Pass the latest message to the view
        return redirect()->back()->with('success', 'Your message has been sent!')->with('latestMessage', $latestMessage);
    }

    // Mark the contact submission as read
    public function markAsRead($id)
    {
        $contactUs = ContactUs::findOrFail($id);
        $contactUs->update(['read' => true]);

        return back()->with('success', 'Notification marked as read.');
    }

    // Mark all messages as read
    public function markAllAsRead()
    {
        ContactUs::where('read', false)->update(['read' => true]);

        return back()->with('success', 'All unread messages marked as read.');
    }

    // Delete selected contact submissions
    public function deleteSelected(Request $request)
    {
        $request->validate([
            'ids' => 'required|array', // Ensure 'ids' is an array
            'ids.*' => 'exists:contact_us,id', // Ensure each id exists in the database
        ]);

        // Delete the selected messages
        ContactUs::whereIn('id', $request->ids)->delete();

        // Return a success response
        return response()->json(['message' => 'Selected messages deleted successfully.']);
    }

    // Delete all read messages
    public function clearAllRead()
    {
        ContactUs::where('read', true)->delete();

        return back()->with('success', 'All read messages have been deleted.');
    }

    // Reply to a contact submission
    // Reply to a contact submission
    public function reply(Request $request, $id)
    {
        // Find the original contact submission
        $contactUs = ContactUs::findOrFail($id);

        // Validate the reply input
        $validated = $request->validate([
            'message' => 'required|string', // Make sure you're using 'message' for the reply field
        ]);

        // Store the reply in the replies table (use the 'message' column instead of 'reply')
        $reply = Reply::create([
            'contact_us_id' => $contactUs->id, // Associate reply with the correct contact_us_id
            'message' => $validated['message'], // Save reply content in the 'message' column
        ]);

        // Send the reply via email to the user
        Notification::route('mail', $contactUs->email)
            ->notify(new ReplyToContactUsNotification($contactUs, $validated['message']));

        return back()->with('success', 'Your reply has been sent!');
    }
}
