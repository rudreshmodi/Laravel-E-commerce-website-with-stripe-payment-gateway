<?php

namespace App\Http\Controllers;

use App\Models\Combo;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class ComboController extends Controller
{
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Get the search term from the request (if provided)
        $search = $request->input('search', '');

        // Start building the query for combos
        $combosQuery = Combo::with(['category', 'subcategory', 'products']);

        // Apply the search filter if a search term is provided
        if (!empty($search)) {
            $combosQuery->where(function ($query) use ($search) {
                $query->where('name', 'like', '%' . $search . '%')
                    ->orWhereHas('category', function ($query) use ($search) {
                        $query->where('name', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('subcategory', function ($query) use ($search) {
                        $query->where('name', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('products', function ($query) use ($search) {
                        $query->where('name', 'like', '%' . $search . '%');
                    });
            });
        }

        // Retrieve the filtered or unfiltered combos (paginate if required)
        $combos = $combosQuery->paginate(10);

        // Fetch all categories, subcategories, and active products for filtering
        $categories = Category::all();
        $subcategories = Subcategory::all();
        $products = Product::where('status', 'active')->get();

        // Return the view with the necessary data
        return view('combos.index', compact('combos', 'categories', 'subcategories', 'products', 'search'));
    }


    public function create()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Fetch categories and their corresponding subcategories
        $categories = Category::all();
        $subcategories = Subcategory::all();

        // Fetch active products
        $products = Product::where('status', 'active')->get();

        return view('combos.create', compact('categories', 'subcategories', 'products'));
    }

    public function getSubcategoriesByCategory($categoryId)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $subcategories = Subcategory::where('category_id', $categoryId)->get();
        return response()->json(['subcategories' => $subcategories]);
    }

    public function store(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Custom validation messages
        $messages = [
            'name.required' => 'The combo name is required.',
            'name.string' => 'The combo name must be a valid string.',
            'total_price.required' => 'The total price is required.',
            'total_price.numeric' => 'The total price must be a valid number.',
            'categories_id.exists' => 'The selected category is invalid.',
            'subcategories_id.exists' => 'The selected subcategory is invalid.',
            'products.required' => 'At least two products must be selected.',
            'products.*.exists' => 'One or more selected products are invalid.',
            'image.image' => 'The image must be a valid image file.',
            'image.mimes' => 'The image must be a file of type: jpeg, png, jpg.',
            'image.max' => 'The image size must not exceed 10MB.',
        ];

        // Validate the incoming request data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'total_price' => 'required|numeric',
            'categories_id' => 'required|integer|exists:categories,id',
            'subcategories_id' => 'required|integer|exists:subcategories,id',
            'products' => 'required|array|min:2',
            'products.*' => 'exists:products,id',
            'disc_price' => 'required|numeric',
            'description' => 'required|string|max:100',
            'image' => 'required|image|mimes:jpeg,png,jpg|max:10240',
        ], $messages);

        // Handle the image upload if an image is provided
        $imagePath = null;
        if ($request->hasFile('image')) {
            // Store the image in the 'combo_images' folder in the public disk
            $imagePath = $request->file('image')->store('combo_images', 'public');
        }

        // Create the combo with validated data
        $combo = Combo::create([
            'name' => $validated['name'],
            'total_price' => $validated['total_price'],
            'categories_id' => $validated['categories_id'],
            'subcategories_id' => $validated['subcategories_id'],
            'disc_price' => $validated['disc_price'] ?? null,
            'description' => $validated['description'] ?? null,
            'image' => $imagePath, // Store the image path in the database
        ]);

        // Attach selected products to the combo
        $combo->products()->attach($validated['products']);

        // Redirect to the combos index with a success message
        return redirect()->route('combos.index')->with('success', 'Combo created successfully!');
    }


    public function show($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $combo = Combo::with(['category', 'subcategory', 'products'])->findOrFail($id);
        return view('combos.show', compact('combo'));
    }

    public function getSubcategories($categoryId)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $subcategories = Subcategory::where('category_id', $categoryId)->get();
        return response()->json($subcategories);
    }

    public function edit($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $combo = Combo::with('products')->findOrFail($id);
        $categories = Category::all();
        $subcategories = Subcategory::all();
        $products = Product::all();

        $selectedCategoryId = $combo->category_id;
        $subcategoriesForSelectedCategory = Subcategory::where('category_id', $selectedCategoryId)->get();

        return view('combos.edit', compact('combo', 'categories', 'subcategoriesForSelectedCategory', 'subcategories', 'products'));
    }

    public function update(Request $request, Combo $combo)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Custom validation messages
        $messages = [
            'name.required' => 'The combo name is required.',
            'name.string' => 'The combo name must be a valid string.',
            'total_price.required' => 'The total price is required.',
            'total_price.numeric' => 'The total price must be a valid number.',
            'categories_id.required' => 'A category must be selected.',
            'categories_id.exists' => 'The selected category is invalid.',
            'subcategory_id.required' => 'A subcategory must be selected.',
            'subcategory_id.exists' => 'The selected subcategory is invalid.',
            'products.required' => 'At least two products must be selected.',
            'products.*.exists' => 'One or more selected products are invalid.',
            'image.image' => 'The image must be a valid image file.',
            'image.mimes' => 'The image must be a file of type: jpeg, png, jpg, gif, svg.',
            'image.max' => 'The image size must not exceed 2MB.',
        ];

        // Validate the incoming request data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'total_price' => 'required|numeric',
            'disc_price' => 'required|numeric',
            'categories_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'products' => 'required|array|min:2|max:6',
            'description' => 'required|string|max:150',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ], $messages);

        // Handle image upload (if any)
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($combo->image && Storage::exists('public/' . $combo->image)) {
                Storage::delete('public/' . $combo->image);
            }

            // Store the new image and update the image path
            $imagePath = $request->file('image')->store('combo_images', 'public');
            $validated['image'] = $imagePath;
        }

        // Update the combo with validated data (including image path if available)
        $combo->update($validated);

        // Sync selected products (many-to-many relationship)
        $combo->products()->sync($validated['products']);

        // Redirect with success message
        return redirect()->route('combos.index')->with('success', 'Combo updated successfully!');
    }


    public function destroy($id)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $combo = Combo::findOrFail($id);

        // Soft delete the combo
        $combo->delete();

        return redirect()->route('combos.index')->with('success', 'Combo deleted successfully.');
    }
}
