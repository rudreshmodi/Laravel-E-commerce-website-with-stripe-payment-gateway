<?php

namespace App\Http\Controllers;

use App\Mail\OrderPlaced;
use App\Mail\PaymentSuccess;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Checkout\Session;
use Stripe\Exception\ApiErrorException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    /**
     * Show the checkout page with cart items.
     */
    public function index()
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }
        // Get cart items for the authenticated user
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Calculate the total of the cart items
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });

        // Check if total is less than 300, then add a shipping fee
        $shippingFee = ($total < 300) ? 25 : 0;

        // Calculate the final total including shipping
        $finalTotal = $total + $shippingFee;

        // Get categories from cart items to fetch recommended products
        $categories = $cartItems->map(function ($item) {
            return $item->product->category_id;
        })->unique();

        // Fetch recommended products based on categories
        $recommendedProducts = Product::whereIn('category_id', $categories)
            ->whereNotIn('id', $cartItems->pluck('product_id'))
            ->limit(8)
            ->get();

        // Pass variables to the view
        return view('user.checkout', compact('cartItems', 'total', 'shippingFee', 'finalTotal', 'recommendedProducts'));
    }

    /**
     * Handle Cash on Delivery checkout.
     */
    public function codCheckout(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }
        // Ensure the cart exists
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Check if the cart is empty
        if ($cartItems->isEmpty()) {
            // Redirect to cart page with an error message if the cart is empty
            return redirect()->route('user.cart')->with('error', 'Your cart is empty.');
        }

        // Calculate the total price and add shipping fee
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });
        $shippingFee = ($total < 300) ? 25 : 0;
        $finalTotal = $total + $shippingFee;

        // Prepare the comma-separated list of product IDs
        $productIds = $cartItems->map(function ($item) {
            return $item->product->id;
        })->toArray(); // Collect all product IDs

        // Create the order with 'cash on delivery' status
        $order = Order::create([
            'user_id' => Auth::id(),
            'total' => $finalTotal,  // Include shipping fee in the final total
            'status' => 'cash on delivery',
            'address' => $request->address,
            'product_id' => implode(",", $productIds), // Store comma-separated product IDs

        ]);

        // Prepare comma-separated details for the products in the cart
        $productNames = [];
        $productImages = [];
        $quantities = [];
        $prices = [];
        $productIds = [];

        foreach ($cartItems as $item) {
            $productNames[] = $item->product->name;
            $productImages[] = asset('storage/' . $item->product->image); // Use correct path or URL for the image
            $quantities[] = $item->quantity;
            $prices[] = $item->product->price;
            $productIds[] = $item->product->id;
        }

        // Save these details to the order
        $order->order_items = implode(",", $productNames);
        $order->order_images = implode(",", $productImages);  // Store full image URLs
        $order->order_quantities = implode(",", $quantities);
        $order->product_id = implode(",", $productIds);  // Store comma-separated product IDs
        $order->order_prices = implode(",", $prices);

        $order->save();

        // Clear the user's cart after placing the order
        CartItem::where('user_id', Auth::id())->delete();
        DB::statement('ALTER TABLE cart_items AUTO_INCREMENT = 1;');

        // Send confirmation email
        Mail::to(Auth::user()->email)->send(new OrderPlaced($order));
        Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));  // Send payment success email for COD

        // Return a success view or redirect to a confirmation page
        return redirect()->route('checkout.success')->with('success', 'Order placed successfully with Cash on Delivery.');
    }

    /**
     * Process payment with Stripe.
     */
    public function process(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $cartItems = CartItem::where('user_id', Auth::id())->get();
        // Prepare the comma-separated list of product IDs
        $productIds = $cartItems->map(function ($item) {
            return $item->product->id;
        })->toArray(); // Collect all product IDs

        // Check if the cart is empty
        if ($cartItems->isEmpty()) {
            return redirect()->route('user.cart')->with('error', 'Your cart is empty.');
        }

        // Calculate the total price and add shipping fee
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });
        $shippingFee = ($total < 300) ? 25 : 0;  // Apply shipping fee if total is less than 300
        $finalTotal = $total + $shippingFee;

        // Handle payment method
        if ($request->payment_method == 'cod') {
            // Handle Cash on Delivery checkout
            return $this->codCheckout($request);
        }

        // Handle Stripe checkout
        if ($request->payment_method == 'stripe') {
            Stripe::setApiKey(env('STRIPE_SECRET'));

            try {
                // Create a Stripe Checkout session
                $session = Session::create([
                    'payment_method_types' => ['card'],
                    'line_items' => array_merge(
                        $cartItems->map(function ($item) {
                            return [
                                'price_data' => [
                                    'currency' => 'inr',  // Set currency to INR
                                    'product_data' => [
                                        'name' => $item->product->name,
                                    ],
                                    'unit_amount' => $item->product->price * 100, // Amount in paise (1 INR = 100 paise)
                                ],
                                'quantity' => $item->quantity,
                            ];
                        })->toArray(),
                        // Add a line item for shipping fee
                        [
                            [
                                'price_data' => [
                                    'currency' => 'inr',  // Set currency to INR
                                    'product_data' => [
                                        'name' => 'Shipping Fee',
                                    ],
                                    'unit_amount' => $shippingFee * 100, // Amount in paise (shipping fee)
                                ],
                                'quantity' => 1, // Shipping is a single line item
                            ]
                        ]
                    ),
                    'mode' => 'payment',
                    'success_url' => route('checkout.success'),
                    'cancel_url' => route('checkout.cancel'),
                ]);

                // Create an order with status 'pending'
                $order = Order::create([
                    'user_id' => Auth::id(),
                    'total' => $finalTotal,  // Include shipping fee in the final total
                    'status' => 'pending', // Status 'pending' until Stripe confirms payment
                    'address' => $request->address,
                    'product_id' => implode(",", $productIds), // Store comma-separated product IDs

                ]);

                // Prepare comma-separated details for the cart
                $productNames = [];
                $productImages = [];
                $quantities = [];
                $prices = [];
                $productIds = [];

                foreach ($cartItems as $item) {
                    $productNames[] = $item->product->name;
                    $productImages[] = asset('storage/products/' . $item->product->image); // Use correct path or URL for the image
                    $quantities[] = $item->quantity;
                    $prices[] = $item->product->price;
                    $productIds[] = $item->product->id;
                }

                // Save comma-separated values in the order
                $order->order_items = implode(",", $productNames);
                $order->order_images = implode(",", $productImages);  // Store full image URLs
                $order->order_quantities = implode(",", $quantities);
                $order->product_id = implode(",", $productIds); // Store product IDs as a comma-separated string
                $order->order_prices = implode(",", $prices);
                $order->save();

                // Redirect to Stripe Checkout
                return redirect()->away($session->url);
            } catch (ApiErrorException $e) {
                return back()->withErrors(['error' => $e->getMessage()]);
            }
        }

        // If no valid payment method is provided, redirect to the checkout page
        return redirect()->route('user.checkout')->with('error', 'Invalid payment method.');
    }

    /**
     * Handle successful payment.
     */
    public function success(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Determine if it's a COD order or a paid Stripe order
        $order = Order::where('user_id', Auth::id())
            ->whereIn('status', ['pending', 'cash on delivery'])  // Check for both COD and pending orders
            ->latest()
            ->first();  // Get the most recent order

        if ($order) {
            // If the order is still in the 'pending' state, update to 'paid'
            if ($order->status == 'pending') {
                $order->update([
                    'status' => 'paid',
                ]);
            }

            // Send the order placed confirmation email
            Mail::to(Auth::user()->email)->send(new OrderPlaced($order));

            // Send payment success email (if payment was successful)
            Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));

            // Clear the user's cart after successful payment
            CartItem::where('user_id', Auth::id())->delete();

            // Reset the auto-increment value of the cart_items table
            DB::statement('ALTER TABLE cart_items AUTO_INCREMENT = 1;');

            // Return success view
            return view('user.paysuccess', compact('order'));
        }

        // If order not found, redirect to some error page
        return redirect()->route('user.paysuccess');
    }

    /**
     * Handle canceled payment.
     */
    public function cancel()
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        $order = Order::where('user_id', Auth::id())
            ->where('status', 'pending')
            ->latest()
            ->first();

        if ($order) {
            $order->update(['status' => 'cancelled']);
        }

        return view('user.cancel', compact('order'));
    }
}
