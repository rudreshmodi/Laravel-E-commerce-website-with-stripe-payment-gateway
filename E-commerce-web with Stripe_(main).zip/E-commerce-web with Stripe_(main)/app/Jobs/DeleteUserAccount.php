<?php

namespace App\Jobs;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class DeleteUserAccount implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The user instance.
     *
     * @var \App\Models\User
     */
    public $user;

    /**
     * Create a new job instance.
     *
     * @param \App\Models\User $user
     * @return void
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {
            // Check if the deletion time has passed (deleted_at)
            if ($this->user->deleted_at && Carbon::now()->greaterThanOrEqualTo($this->user->deleted_at)) {
                // Nullify sensitive user data instead of deleting
                $this->user->update([
                    'name' => null,
                    'email' => null,
                    'password' => null, // Optional: Remove the password if needed
                    'deleted_at' => Carbon::now('Asia/Kolkata'), // Soft-delete the user by setting the `deleted_at` field
                ]);

                Log::info('User account data nullified: ' . $this->user->id);
            } else {
                // Log if the deletion time has not yet come
                Log::info('Deletion time not yet reached for user: ' . $this->user->id);
            }
        } catch (\Exception $e) {
            // Log any errors that occur during the process
            Log::error('Failed to nullify user account data: ' . $this->user->id . ' Error: ' . $e->getMessage());
        }
    }
}