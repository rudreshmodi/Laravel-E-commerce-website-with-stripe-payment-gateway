<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Carbon;

class CustomEmailVerificationNotification extends Notification
{
    public $user;

    /**
     * Create a new notification instance.
     *
     * @param  \App\Models\User  $user
     * @return void
     */
    public function __construct($user)
    {
        $this->user = $user;
    }

    /**
     * Get the notification's mail representation.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        // Generate a signed verification URL
        $verificationUrl = URL::temporarySignedRoute(
            'auth.verify-email', // Named route for verification
            Carbon::now()->addMinutes(60), // Link expires in 60 minutes
            ['token' => $this->user->email_verification_token] // Token as a route parameter
        );

        return (new MailMessage)
                    ->subject('Verify Your Email Address')
                    ->greeting('Hello, ' . $this->user->name)
                    ->line('Thank you for registering with us.')
                    ->action('Verify Email', $verificationUrl)
                    ->line('If you did not register, please ignore this email.');
    }
}
