<?php $__env->startSection('content'); ?>
<div class="container mx-auto top-0">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('Coupon.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">
                        Coupons</a>
                </div>
            </li>
        </ol>

        <!-- Action Button: Trashed Coupons -->
        <div class="flex items-center justify-end ml-4">
            <a 
                class="bg-yellow-500 text-white px-3 py-2 rounded-full shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                Trashed Coupons
            </a>
        </div>
    </div>

    <!-- Filter Bar -->
    <form action="<?php echo e(route('Coupon.index')); ?>" method="GET"
        class="flex justify-between items-center mb-4 bg-gray-50 p-4 rounded-lg shadow-md ">
        <div class="flex space-x-2 w-full max-w-3xl">
            <!-- Search by Coupon Code -->
            <input type="text" name="search" placeholder="Search by coupon code..." value="<?php echo e(request()->search); ?>"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                style="width: 500px;">
            <!-- Apply Filters Button -->
            <button type="submit"
                class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 text-sm">
                <i class="fas fa-filter"></i>
            </button>
            <!-- Reset Filters Button -->
            <a href="<?php echo e(route('Coupon.index')); ?>"
                class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                <i class="fas fa-undo"></i>
            </a>
        </div>
        <div class="flex space-x-2 items-center justify-between">
            <!-- Add New Coupon Button -->
            <a href="<?php echo e(route('Coupon.create')); ?>"
                class="bg-indigo-900 text-white py-2 rounded-full shadow-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300 flex items-center justify-center text-sm"
                style="width: 220px;">
                <i class="fas fa-plus-circle mr-2"></i> Add New Coupon
            </a>
        </div>
    </form>

    <!-- Coupons Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Coupon Code</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Discount Value</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Type</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Start Date</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">End Date</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Status</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($coupon->id); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800 uppercase font-semibold">
                        <?php echo e($coupon->coupon_code); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($coupon->discount_value); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e(ucfirst($coupon->type)); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($coupon->start_date); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($coupon->end_date); ?></td>
                    <td class="px-6 py-4 text-sm">
                        <span
                            class="px-3 py-1 rounded-full text-white text-xs font-medium <?php echo e($coupon->status ? 'bg-green-500' : 'bg-red-500'); ?>">
                            <?php echo e($coupon->status ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-4">
                            <a href="<?php echo e(route('Coupon.show', $coupon->id)); ?>"
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('Coupon.edit', $coupon->id)); ?>"
                                class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button type="button"
                                class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm"
                                onclick="confirmDelete(<?php echo e($coupon->id); ?>)">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="px-6 py-4 text-center text-gray-500 text-sm">No coupons found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4 text-sm">
        <?php echo e($coupons->links()); ?>

        <!-- Pagination Links -->
    </div>
</div>

<script>
    function confirmDelete(couponId) {
        if (confirm('Are you sure you want to delete this coupon?')) {
            document.forms[`delete-form-${couponId}`].submit();
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/Stripe-laravel/resources/views/Coupon/index.blade.php ENDPATH**/ ?>