@extends('layouts.app')

@section('title', 'Product Combos')

@section('content')
    <div class="container mx-auto top-0">
        <!-- Breadcrumb Navigation -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('combos.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Combos</a>
                    </div>
                </li>
            </ol>

            <!-- Action Button: Trashed Categories aligned at the end -->
            <div class="flex items-center justify-end ml-4">
                <a href="{{ route('deleted-combos.index') }}"
                    class="bg-yellow-500 text-white px-3 py-2 rounded-full shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                    Trashed Combos
                </a>
            </div>
        </div>

        <!-- Filter Bar and Action Button -->
        <div class="flex justify-between items-center bg-gray-50 p-4 rounded-lg shadow-md">
            <form action="{{ route('combos.index') }}" method="GET" class="flex items-center space-x-4">
                <input type="text" name="search" id="filter-input" placeholder="Search combos..."
                    value="{{ request()->search }}"
                    class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm w-64">

                <button type="submit" id="filter-button"
                    class="bg-blue-500 text-white px-2 py-2 rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 text-sm"
                    disabled>
                    <i class="fas fa-filter"></i> Filter
                </button>

                <!-- Reset Button -->
                <a href="{{ route('combos.index') }}"
                    class="bg-gray-300 text-black px-4 py-2 rounded-lg hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 ease-in-out flex items-center text-sm">
                    <i class="fas fa-undo py-1"></i>
                </a>
            </form>

            <script>
                const filterInput = document.getElementById('filter-input');
                const filterButton = document.getElementById('filter-button');

                // Function to check if the input is empty or not
                filterInput.addEventListener('input', function() {
                    // Enable/Disable filter button based on input value
                    if (filterInput.value.trim() === '') {
                        filterButton.disabled = true;
                    } else {
                        filterButton.disabled = false;
                    }
                });

                // Optionally, disable the button when the page loads if input is empty
                window.onload = function() {
                    if (filterInput.value.trim() === '') {
                        filterButton.disabled = true;
                    }
                };
            </script>

            <style>
                /* Ensure cursor doesn't appear as pointer when button is disabled */
                #filter-button:disabled {
                    background-color: #d1d5db;
                    /* Light gray for disabled */
                    color: #505153;
                    /* Slightly lighter text */
                    cursor: not-allowed;
                    /* Show the "not-allowed" cursor */
                    opacity: 0.9;
                    /* Reduce opacity to make it look disabled */
                }
            </style>

            <a href="{{ route('combos.create') }}"
                class="bg-indigo-900 text-white p-2 rounded-full shadow-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300 flex items-center justify-center text-sm">
                <i class="fas fa-plus-circle mr-2"></i> Create New Combo
            </a>
        </div>

        <!-- Display Results or No Combo Found Message -->
        <div>
            @if ($combos->isEmpty())
                <!-- No Combo Found Card -->
                <div class="max-w-lg h-48 mx-auto px-4 mt-20 py-0 bg-white shadow-md rounded-lg text-center">
                    <i class="fas fa-search pt-10 text-4xl text-gray-400 mb-4"></i>
                    <h3 class="text-xl font-semibold text-gray-700">No Combos Found</h3>
                    <p class="text-sm text-gray-500 mt-2">Sorry, we couldn't find any combos matching your search.</p>
                </div>
            @else
                <!-- Combos Table -->
                <div class="overflow-x-auto bg-white rounded-lg shadow-xl mt-4">
                    <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                        <thead class="bg-gray-100 text-gray-600">
                            <tr>
                                <th class="px-3 py-3 text-center text-sm font-bold">#</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Name</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Category & Subcategory</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Image</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Product Names</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Disc. Price</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Total Price</th>
                                <th class="px-3 py-3 text-center text-sm font-bold">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">

                            @foreach ($combos as $combo)
                                <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                                    <td class="px-3 py-4 text-sm text-gray-800">{{ $combo->id }}</td>
                                    <td class="px-3 py-4 text-sm text-gray-800 font-semibold">{{ $combo->name }}</td>
                                    <td class="px-3 py-4 text-sm text-gray-800">
                                        {{ $combo->category->name ?? 'No category' }} &
                                        {{ $combo->subcategory->name ?? 'No subcategory' }}
                                    </td>
                                    <td class="px-3 py-4 text-sm text-gray-800">
                                        @if ($combo->image)
                                            <img src="{{ asset('storage/' . $combo->image) }}"
                                                alt="{{ $combo->name }}" class="w-28 h-auto object-cover rounded">
                                        @else
                                            <span class="text-gray-500">No Image</span>
                                        @endif
                                    </td>
                                    <td class="px-3 py-4 text-sm text-gray-800">
                                        @foreach ($combo->products as $product)
                                            <span
                                                class="inline-block px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-200 rounded-lg border border-gray-300 mr-2 mb-2">
                                                {{ $product->name }}
                                            </span>
                                        @endforeach
                                    </td>
                                    <td class="px-3 py-4 text-sm text-gray-800">₹{{ number_format($combo->disc_price, 2) }}
                                    </td>
                                    <td class="px-3 py-4 text-sm text-gray-800">
                                        ₹{{ number_format($combo->total_price, 2) }}</td>
                                    <td class="px-3 py-4 text-sm text-center">
                                        <div class="flex justify-center space-x-2">
                                            <!-- View Button -->
                                            <a href="{{ route('combos.show', $combo->id) }}"
                                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <!-- Edit Button -->
                                            <a href="{{ route('combos.edit', $combo->id) }}"
                                                class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            <!-- Soft Delete Button -->
                                            <button type="button"
                                                class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm"
                                                onclick="openDeleteModal({{ $combo->id }})">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>

                                            <!-- Restore Button (if trashed) -->
                                            @if ($combo->trashed())
                                                <form action="{{ route('combos.restore', $combo->id) }}" method="POST"
                                                    style="display:inline;">
                                                    @csrf
                                                    <button type="submit"
                                                        class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                                        Restore
                                                    </button>
                                                </form>
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>

        <!-- Pagination Links -->
        <div class="mt-4 text-sm">
            {{ $combos->links() }}
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h3 class="text-lg font-semibold mb-4">Are you sure you want to delete this combo?</h3>
            <div class="flex justify-between items-center">
                <button id="cancelDelete"
                    class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">Cancel</button>
                <button id="confirmDelete"
                    class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600">Delete</button>
            </div>
        </div>
    </div>

    <script>
        // Open the delete modal
        function openDeleteModal(comboId) {
            const modal = document.getElementById('deleteModal');
            const cancelBtn = document.getElementById('cancelDelete');
            const confirmBtn = document.getElementById('confirmDelete');

            // Show modal
            modal.classList.remove('hidden');
            confirmBtn.onclick = function() {
                document.getElementById('deleteForm' + comboId).submit();
            };

            // Close modal
            cancelBtn.onclick = function() {
                modal.classList.add('hidden');
            };
        }
    </script>

    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-2 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif
@endsection
