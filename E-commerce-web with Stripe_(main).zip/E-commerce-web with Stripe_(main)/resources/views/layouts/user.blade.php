<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard')</title>

    <!-- TailwindCSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- FontAwesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <!-- jQuery (needed for some plugins and custom JS) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- AlpineJS (for reactive components) -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.js" defer></script>

    <!-- SwiperJS (for carousels or sliders) -->
    <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200..900;1,200..900&display=swap"
        rel="stylesheet">
    <!-- Boxicons (optional icon set) -->
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.1/css/boxicons.min.css" rel="stylesheet">

    <!-- Global app CSS -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="/css/shop.index.css">

    <style>
        /* Custom scrollbar for webkit browsers (Chrome, Safari, Edge) */
        ::-webkit-scrollbar {
            width: 10px;
            height: 8px;
        }

        ::-webkit-scrollbar-thumb {
            background-color: #4C9ED9;
            /* Light Blue color */
            border-radius: 8px;
            border: 2px solid #f0f0f0;
            /* Subtle border for contrast */
            transition: background-color 0.3s ease;
        }

        ::-webkit-scrollbar-thumb:hover {
            background-color: #3B80A7;
            /* Darker Blue on hover */
        }

        ::-webkit-scrollbar-track {
            background-color: #f0f0f0;
            /* Light grey background */
            border-radius: 10px;
        }

        ::-webkit-scrollbar-track:hover {
            background-color: #e0e0e0;
            /* Darker grey on hover */
        }

        ::-webkit-scrollbar-corner {
            background-color: #f0f0f0;
        }

        /* For Firefox */
        scrollbar {
            width: 10px;
            height: 8px;
        }

        scrollbar-thumb {
            background-color: #4C9ED9;
            border-radius: 8px;
            border: 2px solid #f0f0f0;
        }

        scrollbar-thumb:hover {
            background-color: #3B80A7;
        }

        scrollbar-track {
            background-color: #f0f0f0;
            border-radius: 10px;
        }

        scrollbar-track:hover {
            background-color: #e0e0e0;
        }

        /* Smooth scroll behavior */
        html {
            scroll-behavior: smooth;
        }

        /* Hide the custom scrollbar on mobile devices */
        @media (max-width: 768px) {
            ::-webkit-scrollbar {
                display: none;
            }

            scrollbar {
                display: none;
            }
        }
    </style>
</head>


<body class="bg-gray-50 flex flex-col m-0 p-0 min-h-screen">
    <!-- Navbar -->
    <nav class="navbar bg-white shadow-lg sticky top-0 z-50 py-2 px-4 lg:px-0">
        <div class="container mx-auto flex justify-between items-center">
            <!-- Brand Logo -->
            <h1 class="flex items-center space-x-2">
                <a href="{{ route('home') }}" class="h-8 md:h-12">
                    <img src="{{ asset('./img/logo1.jpg') }}" alt="Brand Logo" class="h-8 md:h-12">
                </a>
            </h1>

            <!-- Mobile Hamburger, Search, and Cart -->
            <div class="lg:hidden flex items-center space-x-4 py-2" x-data="{ openMenu: false, openSearch: false }">
                <!-- Search Icon -->
                <button id="search-toggle" class="text-gray-600 text-2xl">
                    <i class="fas fa-search"></i>
                </button>

                <!-- Wishlist Icon -->
                <a href="{{ route('shop.wishlist') }}" class="text-gray-600 text-2xl relative">
                    <i class="fas fa-heart"></i>
                    @php
                    $wishlistCount = count(session()->get('wishlist', []));
                    @endphp
                    <span
                        class="absolute top-0 right-0 -mr-3 -mt-2 inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-lg">
                        {{ $wishlistCount > 0 ? $wishlistCount : 0 }}
                    </span>
                </a>

                <!-- Cart Icon -->
                <a href="{{ route('user.cart') }}" class="text-gray-600 text-2xl relative">
                    <i class="fas fa-shopping-bag"></i>
                    @if (Auth::check())
                    @php
                    $cartCount = App\Models\CartItem::where('user_id', Auth::id())->sum('quantity');
                    @endphp
                    <span
                        class="absolute top-0 right-0 -mr-2 -mt-2 inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-lg">
                        {{ $cartCount > 0 ? $cartCount : 0 }}
                    </span>
                    @endif
                </a>

                <!-- Hamburger Icon -->
                <button id="hamburger-toggle" class="text-gray-600 text-2xl">
                    <i class="fas fa-bars"></i>
                </button>
            </div>

            <!-- Full Search Bar for Desktop -->
            <form id="search-form" action="{{ route('user.search') }}" method="GET"
                class="hidden lg:flex flex-grow mx-4 justify-center" autocomplete="off">
                <div class="relative w-full max-w-lg">
                    <input type="text" id="search-input" name="search"
                        class="px-4 py-2 pl-10 pr-4 border-2 border-gray-300 rounded-l-md w-full"
                        placeholder="Search products..." value="{{ request('search') }}">
                    <i id="clear-input"
                        class="fas fa-times absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 cursor-pointer hidden"
                        title="Clear input"></i>
                </div>
                <button type="submit" id="search-btn"
                    class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 transition disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed"
                    disabled>
                    <i class="fas fa-search"></i>
                </button>
            </form>

            <!-- Navbar Links -->
            <div class="hidden lg:flex items-center space-x-6">
                <a href="{{ route('user.index') }}"
                    class="text-gray-700 hover:text-blue-500 transition duration-300 ease-in-out border-b-2 border-transparent hover:border-blue-500 {{ request()->routeIs('user.index') ? 'text-blue-500 border-blue-500' : '' }}">Home</a>

                <a href="{{ route('user.about-us') }}"
                    class="text-gray-700 hover:text-blue-500 transition duration-300 ease-in-out border-b-2 border-transparent hover:border-blue-500 {{ request()->routeIs('user.about') ? 'text-blue-500 border-blue-500' : '' }}">About
                    Us</a>

                <a href="{{ route('shop.index') }}"
                    class="text-gray-700 hover:text-blue-500 transition duration-300 ease-in-out border-b-2 border-transparent hover:border-blue-500 {{ request()->routeIs('user.shop') ? 'text-blue-500 border-blue-500' : '' }}">Shop</a>

                <a href="{{ route('user.blog') }}"
                    class="text-gray-700 hover:text-blue-500 transition duration-300 ease-in-out border-b-2 border-transparent hover:border-blue-500 {{ request()->routeIs('user.blog') ? 'text-blue-500 border-blue-500' : '' }}">Blog</a>

                <a href="{{ route('shop.wishlist') }}"
                    class="text-gray-600 text-2xl relative hover:text-blue-500 transition duration-300 ease-in-out border-b-2 border-transparent hover:border-blue-500 {{ request()->routeIs('shop.wishlist') ? 'text-blue-500 border-blue-500' : '' }}">
                    <i class="fas fa-heart"></i>
                    <span
                        class="absolute top-0 right-0 -mr-3 -mt-2 inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-lg">
                        {{ $wishlistCount > 0 ? $wishlistCount : 0 }}
                    </span>
                </a>

                <a href="{{ route('user.cart') }}"
                    class="text-gray-600 text-2xl relative hover:text-blue-500 transition duration-300 ease-in-out border-b-2 border-transparent hover:border-blue-500 {{ request()->routeIs('user.cart') ? 'text-blue-500 border-blue-500' : '' }}">
                    <i class="fas fa-shopping-bag"></i>
                    @if (Auth::check())
                    <span
                        class="absolute top-0 right-0 -mr-2 -mt-2 inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-lg">
                        {{ $cartCount > 0 ? $cartCount : 0 }}
                    </span>
                    @endif
                </a>

                @auth
                <div class="relative">
                    <button id="profile-btn" class="flex items-center space-x-2 text-gray-700 hover:text-blue-500">
                        <img id="profileImagePreview"
                            src="{{ asset('storage/' . (Auth::user()->profile_image ?? 'profile_images/Profile.png')) }}"
                            alt="Profile Picture"
                            class="w-10 h-10 rounded-full object-cover border-2 border-white shadow-lg">
                        <i class="fas fa-chevron-down text-sm transform transition-transform duration-200"></i>
                    </button>

                    <ul id="profile-dropdown" class="absolute right-0 w-48 bg-white shadow-lg rounded-lg"
                        style="margin-top: 2px; display: none;">
                        <li>
                            <p
                                class="text-sm text-white text-center text-bold bg-gray-900 py-2 rounded-t-md rounded-r-md mt-2 mb-0">
                                Welcome, {{ Auth::user()->name }}</p>
                        </li>
                        <li>
                            <a href="{{ route('userprofile') }}"
                                class="block px-4 mt-2 justify-items-center pb-2 -pt-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user ml-2"></i><span class="pl-2">My Profile</span>
                            </a>
                        </li>
                        <hr>
                        <li class="flex justify-center items-center">
                            <button onclick="openLogoutModal()"
                                class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold flex items-center">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </button>
                            <form id="logoutForm" action="{{ route('logout') }}" method="POST" class="hidden">
                                @csrf
                            </form>
                        </li>
                    </ul>
                </div>
                @endauth

                @guest
                <a href="{{ route('login') }}" class="text-gray-700 hover:text-blue-500">Login</a>
                @endguest
            </div>
        </div>

        <!-- Search Bar for Mobile -->
        <div id="search-bar" class="hidden bg-white shadow-md py-2 px-4 lg:hidden">
            <form id="search-form-mobile" action="{{ route('user.search') }}" method="GET" autocomplete="off"
                class="flex items-center space-x-4 w-full">
                <input type="text" id="search-input-mobile" name="search"
                    class="px-4 py-2 border-2 border-gray-300 rounded-l-md w-full" placeholder="Search products..."
                    value="{{ request('search') }}">
                <button type="submit" id="search-btn-mobile"
                    class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 transition disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>

        <!-- Mobile Menu (full-screen from right) -->
        <div id="mobile-menu"
            class="lg:hidden px-2 fixed inset-0 bg-white z-50 transform translate-x-full transition-all duration-500">
            <div class="flex justify-end p-4">
                <button id="hamburger-close" class="text-2xl text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="flex flex-col items-center justify-start h-full space-y-6 pt-1">
                <img id="profileImagePreview"
                    src="{{ asset('storage/' . (Auth::user()->profile_image ?? 'profile_images/Profile.png')) }}"
                    alt="Profile Picture" class="w-28 h-28 rounded-full object-cover border-2 border-white shadow-lg">
                <p class="bg-gray-400 text-black rounded-lg py-1 px-6 md:block">Hello, {{ Auth::user()->name }}</p>
                <a href="{{ route('user.index') }}" class="text-xl text-gray-700 hover:text-blue-500">Home</a>
                <a href="{{ route('user.contact-us') }}" class="text-xl text-gray-700 hover:text-blue-500">Contact
                    Us</a>
                <a href="{{ route('shop.index') }}" class="text-xl text-gray-700 hover:text-blue-500">Shop Now</a>

                @auth
                <a href="{{ route('userprofile') }}" class="text-xl text-gray-700 hover:text-blue-500">My Profile</a>
                <li class="flex justify-center items-center">
                    <button type="button"
                        class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold flex items-center"
                        onclick="document.getElementById('logoutForm').submit();">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </button>
                </li>
                @endauth
                @guest
                <a href="{{ route('login') }}" class="text-xl text-gray-700 hover:text-blue-500">Login</a>
                @endguest
            </div>
        </div>
    </nav>


    <!-- Main Content -->
    <div class="main-content flex  flex-col w-full">
        <main class="py-1 px-1 overflow-auto bg-white">
            @yield('content')
        </main>
        <footer class="section-p1">
            <div class="col">
                <img class="logo w-24 h-auto" src="/img/logo1.jpg" alt="">
                <h4>Contact</h4>
                <p><strong>Address:</strong> 562 Wellington Road, Street 32, San Francisco</p>
                <p><strong>Phone:</strong> +01 2222 345 / (+91) 0 123 456 789</p>
                <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
                <div class="follow">
                    <h4>Follow us</h4>
                    <div class="icon">
                        <i class='bx bxl-facebook'></i>
                        <i class='bx bxl-twitter'></i>
                        <i class='bx bxl-instagram'></i>
                        <i class='bx bxl-pinterest-alt'></i>
                        <i class='bx bxl-youtube'></i>
                    </div>
                </div>
            </div>

            <div class="col">
                <h4>About</h4>
                <a href="#">About us</a>
                <a href="#">Devlivery Information</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
                <a href="#">Contact Us</a>
            </div>

            <div class="col">
                <h4>My Account</h4>
                <a href="#">Sign In</a>
                <a href="#">View Cart</a>
                <a href="#">My Wishlist</a>
                <a href="#">Track My Order</a>
                <a href="#">Help</a>
            </div>

            <div class="col install">
                <h4>Install App</h4>
                <p>From App Store or Google Play</p>
                <div class="row">
                    <img src="/img/pay/app.jpg" alt="">
                    <img src="/img/pay/play.jpg" alt="">
                </div>
                <p>Secured Payment Gateways</p>
                <img src="/img/pay/pay.png" alt="">
            </div>

            <div class="copyright">
                <p>© 2025, Rudresh Modi - E-commerce Shopping. All rights reserved.</p>
            </div>
        </footer>
    </div>

    <!-- Footer -->
    {{-- <footer class="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-2 mt-auto">
        <div class="container mx-auto px-6 md:px-12 text-center md:text-left">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <!-- Company Info -->
                <div>
                    <p class="text-lg font-semibold mb-2">© {{ date('Y') }} Your Company. All Rights Reserved.</p>

                </div>

                <!-- Navigation Links -->
                <div class="mt-4 md:mt-0 space-x-4">
                    <a href="/privacy-policy" class="text-gray-300 hover:text-white transition-colors">Privacy
                        Policy</a>
                    <a href="/terms-of-service" class="text-gray-300 hover:text-white transition-colors">Terms of
                        Service</a>
                    <a href="/contact" class="text-gray-300 hover:text-white transition-colors">Contact Us</a>
                </div>

                <!-- Social Media Icons -->
                <div class="mt-4 md:mt-0 space-x-4">
                    <a href="#" class="text-gray-300 hover:text-white transition-colors">
                        <i class="fab fa-facebook-square text-2xl"></i>
                    </a>
                    <a href="#" class="text-gray-300 hover:text-white transition-colors">
                        <i class="fab fa-twitter-square text-2xl"></i>
                    </a>
                    <a href="#" class="text-gray-300 hover:text-white transition-colors">
                        <i class="fab fa-instagram-square text-2xl"></i>
                    </a>
                    <a href="#" class="text-gray-300 hover:text-white transition-colors">
                        <i class="fab fa-linkedin text-2xl"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer> --}}




    <!-- Logout Confirmation Modal -->
    <div id="logoutModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-lg shadow-lg w-full max-w-xl">
            <div class="flex items-center mb-4">
                <i class="fas fa-exclamation-circle text-red-600 text-3xl mr-4"></i>
                <h2 class="text-xl font-semibold text-gray-800">Are you sure you want to log out?</h2>
            </div>
            <p class="text-gray-700 mb-4 text-center">If you log out, you will need to sign in again to continue using
                the application.</p>
            <div class="flex justify-end gap-4 mt-6">
                <button onclick="closeLogoutModal()"
                    class="flex items-center justify-center px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </button>
                <button onclick="document.getElementById('logoutForm').submit();"
                    class="flex items-center justify-center px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-300">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </button>
            </div>
        </div>
    </div>
    <script>
        // Function to open the logout modal
        function openLogoutModal() {
            document.getElementById('logoutModal').classList.remove('hidden');
        }

        // Close logout confirmation modal
        function closeLogoutModal() {
            document.getElementById('logoutModal').classList.add('hidden');
        }

        // Mobile menu toggler (using plain JS)
        const hamburgerToggle = document.getElementById('hamburger-toggle');
        const hamburgerClose = document.getElementById('hamburger-close');
        const mobileMenu = document.getElementById('mobile-menu');

        if (hamburgerToggle) {
            hamburgerToggle.addEventListener('click', function() {
                mobileMenu.style.transform = 'translateX(0)';
            });
        }

        if (hamburgerClose) {
            hamburgerClose.addEventListener('click', function() {
                mobileMenu.style.transform = 'translateX(100%)';
            });
        }

        // Toggle search bar visibility (using plain JS)
        const searchToggle = document.getElementById('search-toggle');
        const searchBar = document.getElementById('search-bar');

        if (searchToggle) {
            searchToggle.addEventListener('click', function() {
                searchBar.classList.toggle('hidden');
            });
        }

        // Function to toggle the cancel button visibility and search button state
        function toggleClearButton() {
            const searchInput = document.getElementById('search-input');
            const clearInput = document.getElementById('clear-input');
            const searchBtn = document.getElementById('search-btn');

            const inputValue = searchInput.value.trim();
            if (inputValue !== "") {
                clearInput.style.display = 'block'; // Show the cancel button if input is not empty
                searchBtn.disabled = false; // Enable the search button
            } else {
                clearInput.style.display = 'none'; // Hide the cancel button if input is empty
                searchBtn.disabled = true; // Disable the search button if input is empty
            }
        }

        // Event listener for search input field to toggle buttons and initiate search
        const searchInput = document.getElementById('search-input');
        const searchResults = document.getElementById('search-results');
        const clearInput = document.getElementById('clear-input');

        if (searchInput) {
            searchInput.addEventListener('input', function() {
                toggleClearButton(); // Check input and toggle buttons accordingly

                const query = searchInput.value.trim();

                if (query.length > 0) {
                    // Perform a search request only if there is text in the input
                    fetch(`{{ route('user.search') }}?search=${encodeURIComponent(query)}`)
                        .then(response => response.text())
                        .then(data => {
                            searchResults.innerHTML = data; // Update search results dynamically
                        })
                        .catch(error => console.error("Error occurred while searching.", error));
                } else {
                    searchResults.innerHTML = ''; // Clear results if the search query is empty
                }
            });
        }

        // Initial call to toggle the button visibility on page load
        toggleClearButton();

        // Clear input and redirect to user.index when cancel button is clicked
        if (clearInput) {
            clearInput.addEventListener('click', function() {
                searchInput.value = ''; // Clear the input field
                toggleClearButton(); // Recheck input value and adjust button visibility

                // Redirect to the user.index route (will reload the page)
                window.location.href = '{{ route('user.index') }}';
            });
        }
    </script>
    <script>
        // Toggle Profile Dropdown
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');

        if (profileBtn) {
            profileBtn.addEventListener('click', function() {
                // Toggle the visibility of the profile dropdown
                if (profileDropdown.style.display === 'block') {
                    profileDropdown.style.display = 'none'; // Close the dropdown if it's already open
                } else {
                    profileDropdown.style.display = 'block'; // Open the dropdown if it's closed
                }
            });

            // Close the dropdown if the user clicks outside of it
            window.addEventListener('click', function(event) {
                if (!profileBtn.contains(event.target) && !profileDropdown.contains(event.target)) {
                    profileDropdown.style.display = 'none'; // Close dropdown if clicked outside
                }
            });
        }

        // Optionally, you could also close the dropdown when the user clicks the logout button
        const logoutButton = document.querySelector('.bg-red-600');
        if (logoutButton) {
            logoutButton.addEventListener('click', function() {
                profileDropdown.style.display = 'none'; // Close the dropdown when logging out
            });
        }
    </script>

</body>

</html>