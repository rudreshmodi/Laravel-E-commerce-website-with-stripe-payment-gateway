<!-- resources/views/coupons/show.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Coupon Details</h1>
    <p><strong>ID:</strong> {{ $coupon->id }}</p>
    <p><strong>Coupon Code:</strong> {{ $coupon->coupon_code }}</p>
    <p><strong>Discount Value:</strong> {{ $coupon->discount_value }}</p>
    <p><strong>Description:</strong> {{ $coupon->description }}</p>
    <p><strong>Type:</strong> {{ ucfirst($coupon->type) }}</p>
    <p><strong>Start Date:</strong> {{ $coupon->start_date }}</p>
    <p><strong>End Date:</strong> {{ $coupon->end_date }}</p>
    <p><strong>Status:</strong> {{ $coupon->status ? 'Active' : 'Inactive' }}</p>
    <a href="{{ route('Coupon.index') }}" class="btn btn-secondary">Back</a>
</div>
@endsection