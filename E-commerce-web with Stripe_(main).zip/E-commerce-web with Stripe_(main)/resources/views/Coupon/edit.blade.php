<!-- resources/views/coupons/edit.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Coupon</h1>
    <form action="{{ route('Coupon.update', $coupon->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="coupon_code">Coupon Code</label>
            <input type="text" name="coupon_code" class="form-control" value="{{ $coupon->coupon_code }}" required>
        </div>
        <div class="form-group">
            <label for="discount_value">Discount Value</label>
            <input type="number" name="discount_value" class="form-control" value="{{ $coupon->discount_value }}"
                required>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" class="form-control">{{ $coupon->description }}</textarea>
        </div>
        <div class="form-group">
            <label for="type">Coupon Type</label>
            <select name="type" class="form-control" required>
                <option value="single" {{ $coupon->type == 'single' ? 'selected' : '' }}>Single</option>
                <option value="multiple" {{ $coupon->type == 'multiple' ? 'selected' : '' }}>Multiple</option>
            </select>
        </div>
        <div class="form-group">
            <label for="start_date">Start Date</label>
            <input type="date" name="start_date" class="form-control" value="{{ $coupon->start_date }}" required>
        </div>
        <div class="form-group">
            <label for="end_date">End Date</label>
            <input type="date" name="end_date" class="form-control" value="{{ $coupon->end_date }}" required>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" class="form-control" required>
                <option value="1" {{ $coupon->status ? 'selected' : '' }}>Active</option>
                <option value="0" {{ !$coupon->status ? 'selected' : '' }}>Inactive</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Coupon</button>
    </form>
</div>
@endsection