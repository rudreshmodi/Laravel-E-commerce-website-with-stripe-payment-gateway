@extends('layouts.app')

@section('title', 'User Details')

@section('content')
    <div class="container mx-auto min-h-screen flex flex-col">
        <!-- Breadcrumb -->
        <div class="flex px-5 py-4 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mb-4"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('user_details.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Users</a>
                    </div>
                </li>

                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">{{ $user->name }}</span>
                    </div>
                </li>
            </ol>
        </div>

        <!-- User Information Section -->
        <div class="bg-white shadow-lg rounded-lg px-8 py-4 mb-2 flex-1 overflow-auto">
            <div class="flex flex-col md:flex-row space-x-8 items-center justify-between">
                <!-- User Profile Image -->
                <div class="flex-shrink-0">
                    <img src="{{ asset('storage/' . ($user->profile_image ?? 'images/placeholder.png')) }}"
                        alt="{{ $user->name }}'s profile picture"
                        class="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-gray-300 shadow-lg object-cover">
                </div>

                <!-- User Basic Info -->
                <div class="flex flex-col justify-between space-y-4 w-full">
                    <h1 class="text-3xl font-semibold text-gray-800">{{ $user->name }}</h1>
                    <div class="flex flex-wrap gap-6">
                        <div class="text-gray-600 text-sm font-medium">
                            <p><strong>Email:</strong> {{ $user->email }}</p>
                            <p><strong>Phone:</strong> {{ $user->mobile_number }}</p>
                        </div>
                        <div class="text-gray-600 text-sm font-medium">
                            <p><strong>Role:</strong> {{ ucfirst($user->role) }}</p>
                            <p><strong>Member Since:</strong> {{ $user->created_at->format('M d, Y') }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- User Details Table -->
            <div class="mt-8">
                <h3 class="text-2xl font-semibold text-gray-800 mb-6">Account Details</h3>
                <table class="min-w-full table-auto border-collapse">
                    <tbody class="text-sm text-gray-700">
                        <tr class="border-b">
                            <th class="px-4 py-2 font-medium text-left">ID</th>
                            <td class="px-4 py-2">{{ $user->id }}</td>
                        </tr>
                        <tr class="border-b">
                            <th class="px-4 py-2 font-medium text-left">Email Verified</th>
                            <td class="px-4 py-2">
                                @if ($user->email_verified_at)
                                    <span class="text-green-600">Verified on
                                        {{ $user->email_verified_at->format('M d, Y') }}</span>
                                @else
                                    <span class="text-red-600">Not Verified</span>
                                @endif
                            </td>
                        </tr>
                        <tr class="border-b">
                            <th class="px-4 py-2 font-medium text-left">Two Factor Authentication</th>
                            <td class="px-4 py-2">
                                @if ($user->two_factor_confirmed_at)
                                    <span class="text-green-600">Enabled since
                                        {{ $user->two_factor_confirmed_at->format('M d, Y') }}</span>
                                @else
                                    <span class="text-red-600">Not Enabled</span>
                                @endif
                            </td>
                        </tr>
                        <tr class="border-b">
                            <th class="px-4 py-2 font-medium text-left">Created At</th>
                            <td class="px-4 py-2">{{ $user->created_at->format('M d, Y H:i') }}</td>
                        </tr>
                        <tr>
                            <th class="px-4 py-2 font-medium text-left">Updated At</th>
                            <td class="px-4 py-2">{{ $user->updated_at->format('M d, Y H:i') }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Action Buttons -->
            <div class="flex justify-end space-x-4 mt-8">
                <a href="{{ route('user_details.edit', $user->id) }}"
                    class="px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 ease-in-out transform hover:scale-105">
                    <i class="fa-solid fa-pencil"></i> Edit User
                </a>
                <form action="{{ route('user_details.destroy', $user->id) }}" method="POST" class="inline-block">
                    @csrf
                    @method('DELETE')
                    <button type="submit"
                        class="px-6 py-3 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 focus:ring-4 focus:ring-red-300 transition duration-200 ease-in-out transform hover:scale-105"
                        onclick="return confirm('Are you sure you want to delete this user?')">
                        <i class="fas fa-trash-alt"></i> Delete User
                    </button>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .container {
            max-width: 1200px;
        }

        table {
            width: 100%;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
        }

        table th {
            background-color: #f3f4f6;
        }

        table td {
            background-color: white;
        }

        /* Styling for the action buttons */
        .action-button {
            transition: transform 0.2s ease, background-color 0.3s;
        }

        .action-button:hover {
            transform: scale(1.05);
        }
    </style>
@endpush
