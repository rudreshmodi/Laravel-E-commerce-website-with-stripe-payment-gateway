@extends('layouts.user')

@section('title', 'Payment Canceled')

@section('content')
<section class="py-12">
    <div class="container mx-auto text-center">
        <h1 class="text-4xl font-bold text-red-500 mb-4">Payment Canceled</h1>
        <p class="text-lg">Your payment was canceled. Please try again or contact support if you have any issues.</p>
        <a href="{{ route('user.cart') }}" class="text-blue-500 mt-4 inline-block">Go Back to Cart</a>
    </div>
</section>
@endsection
