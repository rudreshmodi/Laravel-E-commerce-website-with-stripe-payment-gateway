@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-0">
        <!-- Breadcrumb -->
        <div class="flex px-3 mb-2 py-5 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('categories.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Categories</a>
                    </div>
                </li>

                <!-- Current Page -->
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400"> Category Have
                            products</span>
                    </div>
                </li>
            </ol>
        </div>

        <div class="bg-white px-4 py-2 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">

            <!-- Heading with Centered and Uppercase Category Name -->
            <h1 class="text-2xl font-semibold text-gray-800 mb-6 text-center uppercase">
                Products for Category: {{ $category->name }}
            </h1>

            <!-- Card View -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-6">

                @if ($products->count())
                    @foreach ($products as $product)
                        <div class="bg-white rounded-lg shadow-md overflow-hidden">

                            <!-- Image Carousel Section -->
                            <div class="carousel-container">
                                @php
                                    $images = explode(',', $product->images); // Split image paths into array
                                @endphp

                                @if (count($images) > 1)
                                    <!-- Carousel Wrapper -->
                                    <div id="carousel-{{ $product->id }}" class="carousel relative">
                                        <!-- Carousel Images -->
                                        <div class="carousel-images">
                                            @foreach ($images as $index => $image)
                                                <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                                    <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                                                        class="w-56 h-48 object-cover rounded-md mx-auto cursor-pointer">
                                                </div>
                                            @endforeach
                                        </div>

                                        <!-- Navigation Buttons -->
                                        <button
                                            class="carousel-prev absolute left-0 top-1/2 transform -translate-y-1/2 bg-gray-700 text-white px-2">
                                            &lt;
                                        </button>
                                        <button
                                            class="carousel-next absolute right-0 top-1/2 transform -translate-y-1/2 bg-gray-700 text-white px-2">
                                            &gt;
                                        </button>
                                    </div>
                                @else
                                    <!-- Single Image Fallback -->
                                    <img src="{{ asset('storage/' . $images[0]) }}" alt="{{ $product->name }}"
                                        class="w-full h-48 object-cover rounded-md mx-auto cursor-pointer">
                                @endif
                            </div>

                            <!-- Product Details -->
                            <a href="{{ route('products.show', $product->id) }}" class="block">
                                <div class="p-4">
                                    <!-- Product Title -->
                                    <h3 class="text-lg font-semibold text-gray-800 mb-2">
                                        {{ Str::limit($product->name, 30, '...') }}</h3>

                                    <!-- Product Description with truncation (line-clamp) -->
                                    <p class="text-xs text-gray-600 mb-4 line-clamp-2">
                                        {{ Str::limit($product->description, 100, '...') }}
                                    </p>

                                    <!-- Product Price and Category -->
                                    <div class="flex justify-between text-sm text-gray-600">
                                        <p><strong>Price:</strong> ${{ number_format($product->price, 2) }}</p>
                                        <p><strong>Category:</strong> {{ $product->category->name ?? 'N/A' }}</p>
                                    </div>
                                </div>
                            </a>

                        </div>
                    @endforeach
                @else
                    <div class="col-span-full text-center text-gray-500 py-6">
                        <p>No products found for this category. <a href="{{ route('products.create') }}"
                                class="text-blue-500 underline">Create one</a> now!</p>
                    </div>
                @endif

            </div>



            <!-- Pagination -->
            <div class="mt-6">
                {{ $products->links() }}
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Loop through each carousel and add functionality
            document.querySelectorAll('.carousel').forEach(function(carousel) {
                const items = carousel.querySelectorAll('.carousel-item');
                let currentIndex = 0;

                // Function to show the next image
                function showNext() {
                    items[currentIndex].classList.remove('active');
                    currentIndex = (currentIndex + 1) % items.length;
                    items[currentIndex].classList.add('active');
                }

                // Function to show the previous image
                function showPrev() {
                    items[currentIndex].classList.remove('active');
                    currentIndex = (currentIndex - 1 + items.length) % items.length;
                    items[currentIndex].classList.add('active');
                }

                // Set up event listeners for next and previous buttons
                carousel.querySelector('.carousel-next').addEventListener('click', showNext);
                carousel.querySelector('.carousel-prev').addEventListener('click', showPrev);
            });
        });
    </script>

    <style>
        .carousel {
            position: relative;
            width: 100%;
            max-width: 300px;
            margin: 0 auto;
        }

        .carousel-images {
            display: flex;
            overflow: hidden;
            position: relative;
        }

        .carousel-item {
            display: none;
            transition: opacity 0.5s ease-in-out;
        }

        .carousel-item img {
            width: 100%;
            height: auto;
        }

        .carousel-item.active {
            display: block;
        }

        .carousel-prev,
        .carousel-next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.5rem;
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            /* Slight transparent background for visibility */
            border: none;
            cursor: pointer;

            z-index: 10;


        }

        .carousel-prev {
            left: 10px;
        }

        .carousel-next {
            right: 10px;
        }
    </style>
@endsection
