@extends('layouts.app')

@section('title', 'Create Category')

@section('content')

<div class="container mt-6 px-4">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <li class="inline-flex items-center">
                <a href="{{ route('dashboard') }}"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 1 1 1-1h2a1 1 0 1 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="{{ route('categories.index') }}"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Categories</a>
                </div>
            </li>
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Create
                        Category</span>
                </div>
            </li>
        </ol>
    </div>

    <!-- Form Container -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl mt-6">
        <h2 class="text-3xl font-semibold text-gray-800 mb-6"><i class="fas fa-plus-circle mr-2"></i> Add New Category
        </h2>
        <form action="{{ route('categories.store') }}" method="POST" class="space-y-6" enctype="multipart/form-data"
            id="categoryForm">
            @csrf

            <!-- Name -->
            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">Category Name <span
                        class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="{{ old('name') }}"
                    class="block w-full mt-1 px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                @error('name')
                <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Description -->
            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">Description <span
                        class="text-red-500">*</span></label>
                <textarea name="description" id="description" rows="4" maxlength="100"
                    class="block w-full mt-1 px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">{{ old('description') }}</textarea>
                <div class="text-sm text-gray-500 mt-1">
                    <span id="charCount">{{ strlen(old('description')) }}</span> / 100
                </div>
                @error('description')
                <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Image -->
            <div>
                <label for="image" class="block text-sm font-medium text-gray-700">Image <span
                        class="text-red-500">*</span></label>
                <input type="file" name="image" id="image" accept="image/*"
                    class="block w-full mt-1 px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                <p id="imageSizeError" class="text-sm text-red-500 mt-1 hidden">Image size must not exceed 10MB.</p>
                <div id="imagePreviewContainer" class="mt-2 hidden">
                    <img id="imagePreview" src="#" alt="Preview" class="w-32 h-32 object-cover rounded-lg">
                </div>
                @error('image')
                <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Submit -->
            <div class="flex justify-end space-x-4">
                <a href="{{ route('categories.index') }}"
                    class="px-6 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</a>
                <button type="submit" id="submitButton"
                    class="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Create</button>
            </div>
        </form>
    </div>
</div>
<script>
    const nameInput = document.getElementById('name');
    const descriptionTextarea = document.getElementById('description');
    const imageInput = document.getElementById('image');
    const charCount = document.getElementById('charCount');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const imageSizeError = document.getElementById('imageSizeError');
    const submitButton = document.getElementById('submitButton');
    const form = document.getElementById('categoryForm');

    // Validate name
    const validateName = () => {
        const name = nameInput.value.trim();
        if (name === '') {
            nameInput.classList.add('border-red-500');
            nameInput.nextElementSibling.textContent = 'Category name is required.';
            return false;
        }
        nameInput.classList.remove('border-red-500');
        nameInput.nextElementSibling.textContent = '';
        return true;
    };

    // Validate description
    const validateDescription = () => {
        const description = descriptionTextarea.value.trim();
        if (description === '' || description.length > 100) {
            descriptionTextarea.classList.add('border-red-500');
            descriptionTextarea.nextElementSibling.textContent = 
                description === '' ? 'Description is required.' : 'Description must not exceed 100 characters.';
            return false;
        }
        descriptionTextarea.classList.remove('border-red-500');
        descriptionTextarea.nextElementSibling.textContent = '';
        return true;
    };

    // Validate image
    const validateImage = () => {
        const file = imageInput.files[0];
        if (!file) {
            imageInput.classList.add('border-red-500');
            imageInput.nextElementSibling.textContent = 'Image is required.';
            return false;
        } else if (file.size > 10 * 1024 * 1024) {
            imageInput.classList.add('border-red-500');
            imageInput.nextElementSibling.textContent = 'Image size must not exceed 10MB.';
            return false;
        }
        imageInput.classList.remove('border-red-500');
        imageInput.nextElementSibling.textContent = '';
        return true;
    };

    // Update character count
    descriptionTextarea.addEventListener('input', () => {
        charCount.textContent = descriptionTextarea.value.length;
        validateDescription();
    });

    // Image preview and size validation
    imageInput.addEventListener('change', () => {
        const file = imageInput.files[0];
        if (file) {
            if (file.size > 10 * 1024 * 1024) {
                imageSizeError.classList.remove('hidden');
                imagePreviewContainer.classList.add('hidden');
                submitButton.disabled = true;
            } else {
                imageSizeError.classList.add('hidden');
                submitButton.disabled = false;
                const reader = new FileReader();
                reader.onload = () => {
                    imagePreview.src = reader.result;
                    imagePreviewContainer.classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            }
        } else {
            imageSizeError.classList.add('hidden');
            imagePreviewContainer.classList.add('hidden');
            submitButton.disabled = false;
        }
        validateImage();
    });

    // Form submission validation
    form.addEventListener('submit', (e) => {
        const isNameValid = validateName();
        const isDescriptionValid = validateDescription();
        const isImageValid = validateImage();

        if (!isNameValid || !isDescriptionValid || !isImageValid) {
            e.preventDefault(); // Prevent form submission if any field is invalid
        }
    });

    // On blur validation
    nameInput.addEventListener('blur', validateName);
    descriptionTextarea.addEventListener('blur', validateDescription);
    imageInput.addEventListener('blur', validateImage);
</script>

@endsection