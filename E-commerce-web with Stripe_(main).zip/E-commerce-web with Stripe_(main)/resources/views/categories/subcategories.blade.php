@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-0">
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">

                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('categories.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Categories</a>
                    </div>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-700 md:ms-2 dark:text-gray-400">Subcategories</span>
                    </div>
                </li>
            </ol>


        </div>



        <div class="bg-white rounded-lg shadow-md overflow-hidden p-8 m-0">
            <!-- Heading with Centered and Uppercase Category Name -->
            <h1 class="text-2xl font-semibold text-gray-800 mb-6 text-center uppercase">
                Subcategories for Category: {{ $category->name }}
            </h1>
            <!-- Card View for Subcategories -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                @if ($subcategories->count())
                    @foreach ($subcategories as $subcategory)
                        <a href="{{ route('subcategories.show', $subcategory->id) }}" class="block">
                            <div class="bg-white rounded-lg shadow-md overflow-hidden p-2">
                                <img src="{{ $subcategory->image ? asset('storage/' . $subcategory->image) : asset('images/placeholder.png') }}"
                                    alt="{{ $subcategory->name }}" class="w-full h-48 object-cover">
                                <div class="p-4">
                                    <h3 class="text-lg font-semibold text-gray-800">{{ $subcategory->name }}</h3>
                                    <!-- Description with Truncation -->
                                    <p class="text-sm text-gray-600 mt-2 line-clamp-2">
                                        <strong>Description:</strong> {{ $subcategory->description }}
                                    </p>
                                    <p class="text-sm text-gray-600 mt-2"><strong>Category:</strong> {{ $category->name }}
                                    </p>
                                </div>
                            </div>
                        </a>
                    @endforeach
                @else
                    <div class="col-span-full text-center text-gray-500 py-6">
                        <p>No subcategories found for this category. <a href="{{ route('subcategories.create') }}"
                                class="text-blue-500 underline">Create one</a> now!</p>
                    </div>
                @endif
            </div>

            <!-- Pagination -->
            <div class="mt-6">
                {{ $subcategories->links() }}
            </div>
        </div>

        <!-- Success Toast -->
        @if (session('success'))
            <div id="successToast"
                class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                <i class="fas fa-check-circle text-white text-2xl"></i>
                <span>{{ session('success') }}</span>
            </div>
            <script>
                setTimeout(() => {
                    document.querySelector('#successToast').style.display = 'none';
                }, 4000);
            </script>
        @endif

        <!-- Error Toast -->
        @if (session('error'))
            <div id="errorToast"
                class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                <i class="fas fa-times-circle text-white text-2xl"></i>
                <span>{{ session('error') }}</span>
            </div>
            <script>
                setTimeout(() => {
                    document.querySelector('#errorToast').style.display = 'none';
                }, 4000);
            </script>
        @endif
    @endsection
