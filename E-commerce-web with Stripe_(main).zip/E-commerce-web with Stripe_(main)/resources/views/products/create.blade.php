@extends('layouts.app')

@section('title', 'Create Product')

@section('content')
<div class="container mx-auto mt-0">

    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="{{ route('dashboard') }}"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="{{ route('products.index') }}"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Products</a>
                </div>
            </li>

            <!-- Current Page -->
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Create
                        Products</span>
                </div>
            </li>
        </ol>
    </div>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl">

        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-plus-circle mr-2"></i> Add New Product
            </h2>
        </div>

        <!-- Form to Create Product -->
        <form id="productForm" action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data"
            class="space-y-6">
            @csrf

            <!-- Flex container for category and subcategory -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Product Category -->
                <div>
                    <label for="category_id" class="block text-sm font-medium text-gray-700">Category <span
                            class="text-red-500">*</span></label>
                    <select name="category_id" id="category_id"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 {{ $errors->has('category_id') ? 'border-red-500' : '' }}">
                        <option value="">Select Category</option>
                        @foreach ($categories as $category)
                        <option value="{{ $category->id }}" {{ old('category_id')==$category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                        @endforeach
                    </select>
                    @error('category_id')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Product Subcategory (Based on Category) -->
                <div>
                    <label for="subcategory_id" class="block text-sm font-medium text-gray-700">Subcategory <span
                            class="text-red-500">*</span></label>
                    <select name="subcategory_id" id="subcategory_id"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 {{ $errors->has('subcategory_id') ? 'border-red-500' : '' }}">
                        <option value="">Select Subcategory</option>
                    </select>
                    @error('subcategory_id')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Flex container for product name and price -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Product Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">Product Name <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="text" name="name" id="name" value="{{ old('name') }}"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 {{ $errors->has('name') ? 'border-red-500' : '' }}">
                        <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    @error('name')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Product Price -->
                <div>
                    <label for="price" class="block text-sm font-medium text-gray-700">Product Price <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="number" name="price" id="price" value="{{ old('price') }}" step="0.01" min="0"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 {{ $errors->has('price') ? 'border-red-500' : '' }}">
                        <i
                            class="fas fa-dollar-sign absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    @error('price')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Product Description (With Character Count) -->
            <div class="mb-6">
                <label for="description" class="block text-sm font-medium text-gray-700">
                    Product Description <span class="text-red-500">*</span>
                </label>
                <div class="relative flex flex-col">
                    <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()"
                        class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 {{ $errors->has('description') ? 'border-red-500' : '' }}"></textarea>
                    <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
                <div class="text-sm text-gray-500 mt-1">
                    <span id="charCount" class="text-sm text-gray-500">0</span>
                    <span class="text-sm text-gray-500"> / 255</span>
                </div>
                @error('description')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>


            <!-- Product Images (Multiple files) -->
            <div class="mb-6">
                <label for="images" class="block text-sm font-medium text-gray-700">Product Images</label>
                <input type="file" name="images[]" id="images" accept="image/*" multiple
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                @error('images')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror

                <!-- Image Preview -->
                <div id="imagePreviews" class="mt-2 flex space-x-4"></div>
                <p id="imageError" class="mt-2 text-sm text-red-500 hidden">One or more images exceed the size limit
                    (5MB each).</p>
            </div>

            <!-- Product Status (Selector) -->
            <div class="mb-6">
                <label for="status" class="block text-sm font-medium text-gray-700">Product Status <span
                        class="text-red-500">*</span></label>
                <select name="status" id="status"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 {{ $errors->has('status') ? 'border-red-500' : '' }}">
                    <option value="" disabled {{ old('status') ? '' : 'selected' }}>Please choose a status
                    </option>
                    <option value="active" {{ old('status')=='active' ? 'selected' : '' }}>Active</option>
                    <option value="inactive" {{ old('status')=='inactive' ? 'selected' : '' }}>Inactive</option>
                </select>
                @error('status')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-4">
                <a href="{{ route('products.index') }}"
                    class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit" id="submitButton"
                    class="bg-gray-300 text-gray-500 px-6 py-2 rounded border border-gray-400 cursor-not-allowed flex items-center"
                    disabled>
                    <i class="fas fa-check-circle mr-2"></i> Create Product
                </button>


            </div>
        </form>
    </div>
    <script>
        function updateCharCount() {
            const textarea = document.getElementById('description');
            const charCount = document.getElementById('charCount');
            charCount.textContent = textarea.value.length;
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            function updateButtonState(isValid) {
                const submitButton = $('#submitButton');
                if (isValid) {
                    submitButton.prop('disabled', false)
                        .removeClass('bg-gray-300 text-gray-500 cursor-not-allowed')
                        .addClass('bg-blue-500 text-white cursor-pointer');
                } else {
                    submitButton.prop('disabled', true)
                        .removeClass('bg-blue-500 text-white cursor-pointer')
                        .addClass('bg-gray-300 text-gray-500 cursor-not-allowed');
                }
            }

            // When the category changes, make an AJAX call to get the subcategories
            $('#category_id').change(function() {
                const categoryId = $(this).val();
                const subcategoryDropdown = $('#subcategory_id');

                // Clear previous subcategory options
                subcategoryDropdown.empty().append('<option value="">Select Subcategory</option>');

                if (categoryId) {
                    // Make an AJAX request to fetch subcategories based on the selected category
                    $.ajax({
                        url: `/get-subcategories/${categoryId}`,
                        method: 'GET',
                        success: function(data) {
                            if (data.length > 0) {
                                $.each(data, function(index, subcategory) {
                                    subcategoryDropdown.append(`<option value="${subcategory.id}">${subcategory.name}</option>`);
                                });
                            } else {
                                subcategoryDropdown.append('<option value="">No subcategories available</option>');
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching subcategories:', error);
                        }
                    });
                }
            });

            // Image preview with size validation
            $('#images').change(function(event) {
                const files = event.target.files;
                const imagePreviews = $('#imagePreviews');
                const imageError = $('#imageError');
                imagePreviews.empty(); // Clear previous previews
                imageError.addClass('hidden'); // Hide error message

                let validImages = true;

                if (files.length === 0) {
                    validImages = false; // No files selected
                }

                // Loop through selected files and create image preview
                $.each(files, function(index, file) {
                    if (file.size > 10 * 1024 * 1024) { // Check if file size exceeds 10MB
                        validImages = false;
                        return false; // Break the loop
                    }

                    const reader = new FileReader();

                    reader.onload = function(e) {
                        const img = $('<img>').attr('src', e.target.result).addClass('w-12 h-12 object-cover rounded-md cursor-pointer');
                        imagePreviews.append(img);

                        // Add click event for zoom functionality
                        img.click(function() {
                            openZoomModal(e.target.result);
                        });
                    };

                    reader.readAsDataURL(file);
                });

                if (!validImages) {
                    imageError.text("Please upload at least one valid image (each under 10MB).");
                    imageError.removeClass('hidden'); // Show error message
                    $('#productForm').data('validImages', false); // Set flag to false
                } else {
                    imageError.addClass('hidden'); // Hide error message
                    $('#productForm').data('validImages', true); // Set flag to true
                }

                // Check form validity after image change
                checkFormValidity();
            });

            // Function to check form validity
            function checkFormValidity() {
                let isValid = true;

                // Validate Name field
                if ($('#name').val().trim() === '') {
                    isValid = false;
                }

                // Validate Price field
                if ($('#price').val().trim() === '' || parseFloat($('#price').val()) <= 0) {
                    isValid = false;
                }

                // Validate Description field
                if ($('#description').val().trim() === '') {
                    isValid = false;
                }

                // Validate Category and Subcategory
                if ($('#category_id').val() === '' || $('#subcategory_id').val() === '') {
                    isValid = false;
                }

                // Validate Status
                if ($('#status').val().trim() === '') {
                    isValid = false;
                }

                // Validate Images
                if ($('#productForm').data('validImages') === false || $('#images').get(0).files.length === 0) {
                    isValid = false;
                }

                // Update the button state
                updateButtonState(isValid);
            }

            // Attach event listeners to input fields to check validity on input change
            $('#productForm input, #productForm select, #productForm textarea').on('input change', function() {
                checkFormValidity();
            });

            // Form validation on submit
            $('#productForm').submit(function(e) {
                let isValid = true;

                // Clear previous error messages
                $('.error-message').remove();

                // Validate fields (similar to checkFormValidity)
                if ($('#name').val().trim() === '') {
                    $('#name').addClass('border-red-500');
                    $('#name').after('<div class="error-message text-red-500">Name is required.</div>');
                    isValid = false;
                } else {
                    $('#name').removeClass('border-red-500');
                }

                if ($('#images').get(0).files.length === 0) {
                    $('#images').addClass('border-red-500');
                    $('#images').after('<div class="error-message text-red-500">At least one image is required.</div>');
                    isValid = false;
                } else {
                    $('#images').removeClass('border-red-500');
                }

                if (!isValid) {
                    e.preventDefault(); // Prevent form submission if validation fails
                }

                // Update the button state
                updateButtonState(isValid);
            });

            // Zoom modal functionality
            function openZoomModal(imgSrc) {
                const zoomModal = $('#zoomModal');
                const zoomedImg = $('#zoomedImg');
                zoomedImg.attr('src', imgSrc);
                zoomModal.removeClass('hidden'); // Show modal
            }

            // Close zoom modal
            $('#closeZoom').click(function() {
                $('#zoomModal').addClass('hidden'); // Hide modal
            });

            // Allow zoom in/out by scrolling on the modal
            let zoomLevel = 1;
            $('#zoomModal').on('wheel', function(event) {
                if (event.originalEvent.deltaY < 0) {
                    zoomLevel += 0.1; // Zoom in
                } else {
                    zoomLevel -= 0.1; // Zoom out
                }
                zoomLevel = Math.max(0.5, Math.min(3, zoomLevel)); // Limit zoom level
                $('#zoomedImg').css('transform', `scale(${zoomLevel})`);
            });

            // Initial check on page load
            checkFormValidity();
        });
    </script>


    @endsection