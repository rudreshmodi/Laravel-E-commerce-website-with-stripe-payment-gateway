@extends('layouts.user')

@section('title', 'Product Cards')

@section('content')
    <!-- Product Cards Section -->
    <section class="py-12">
        <div class="container mx-auto text-center">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">All Products</h2>

            <!-- Product Cards Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                @foreach ($products as $product)
                    <div
                        class="bg-white p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">

                        <!-- Product Images (Carousel or Grid) -->
                        <div class="mb-4">
                            @php
                                $images = explode(',', $product->images); // Assuming images are stored as a comma-separated string
                            @endphp
                            <div class="grid grid-cols-2 gap-2">
                                @foreach ($images as $image)
                                    @if (file_exists(storage_path('app/public/' . $image)))
                                        <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                                            class="w-full h-40 object-cover rounded">
                                    @else
                                        <img src="{{ asset('images/placeholder.png') }}" alt="Placeholder Image"
                                            class="w-full h-40 object-cover rounded">
                                    @endif
                                @endforeach
                            </div>
                        </div>

                        <!-- Product Name -->
                        <h3 class="text-lg font-semibold mt-4">{{ $product->name }}</h3>

                        <!-- Product Description -->
                        <p class="text-gray-600 text-sm mt-2">{{ Str::limit($product->description, 100) }}</p>

                        <!-- Product Price -->
                        <p class="text-lg font-bold mt-4">${{ number_format($product->price, 2) }}</p>

                        <!-- Add to Cart Button -->
                        <div class="mt-4">
                            <form action="{{ route('cart.add', $product) }}" method="POST">
                                @csrf
                                <button type="submit"
                                    class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">Add to
                                    Cart</button>
                            </form>
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Pagination (if needed) -->
            <div class="mt-6">
                {{ $products->links() }}
            </div>
        </div>
    </section>
@endsection
