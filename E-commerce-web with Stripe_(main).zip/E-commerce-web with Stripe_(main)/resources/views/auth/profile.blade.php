@extends('layouts.app')

@section('content')
<div class="flex items-start justify-center" style="height: 60vh;">
    <div class="bg-white shadow-lg rounded-lg p-10 w-full" style="height: 500px;">
        <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Profile</h2>

        @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span>{{ session('success') }}</span>
        </div>
        <script>
            setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
        </script>
        @endif

        @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span>{{ session('error') }}</span>
        </div>
        <script>
            setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
        </script>
        @endif

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Profile Image and Form -->
            <div>
                <div class="flex justify-center mb-8">
                    <img id="profileImagePreview"
                        src="{{ asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png')) }}"
                        alt="Profile Picture"
                        class="w-32 h-32 rounded-full object-cover border-4 border-indigo-500 shadow-lg">
                </div>

                <form action="{{ route('profile.update.image') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <!-- Use PUT for updating data -->

                    <div class="mb-6 text-center">
                        <label for="profile_image" class="block text-gray-700 font-medium mb-2">Update Profile
                            Image</label>

                        <!-- Flex container for input and button -->
                        <div class="flex items-center space-x-2">
                            <!-- File Input -->
                            <input type="file" name="profile_image" id="profile_image" accept="image/*"
                                class="w-full sm:w-auto p-2 border rounded-lg bg-indigo-500 text-white font-semibold cursor-pointer transition duration-300 ease-in-out hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                onchange="previewImage(event)">

                            <!-- Submit Button -->
                            <button type="submit" id="updateProfileBtn"
                                class="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 transition duration-300 ease-in-out disabled:opacity-50 disabled:bg-gray-600 disabled:cursor-not-allowed"
                                disabled>
                                <i class="fa-solid fa-floppy-disk"></i>
                            </button>

                        </div>

                        @error('profile_image')
                        <div class="text-red-500 text-sm mt-2">{{ $message }}</div>
                        @enderror
                    </div>
                </form>

            </div>

            <!-- User Details -->
            <div>
                <div class="space-y-6">
                    <div class="flex justify-between">
                        <label for="name" class="text-gray-700 font-medium">Name</label>
                        <div class="text-gray-800">{{ $user->name }}</div>
                    </div>

                    <div class="flex justify-between">
                        <label for="email" class="text-gray-700 font-medium">Email</label>
                        <div class="text-gray-800" id="emailSection">
                            <!-- Initially display partial email and hide full email -->
                            <span id="maskedEmail">{{ substr($user->email, 0, 3) }}XXX{{ substr($user->email, 6)
                                }}</span>
                            <span id="fullEmail" style="display:none;">{{ $user->email }}</span>
                            <i class="fas fa-eye" id="toggleEmail" style="cursor: pointer;"></i>
                        </div>
                    </div>

                    <div class="flex justify-between">
                        <label for="email" class="text-gray-700 font-medium">Mobile Number</label>
                        <div class="text-gray-800" id="mobileNumberSection">
                            <!-- Initially display partial number and hide full number -->
                            <span id="maskedNumber">{{ substr($user->mobile_number, 0, 7) }}XXX{{
                                substr($user->mobile_number, 10, 15) }}</span>
                            <span id="fullNumber" style="display:none;">{{ $user->mobile_number }}</span>
                            <i class="fas fa-eye" id="toggleMobileNumber" style="cursor: pointer;"></i>
                        </div>
                    </div>

                    <div class="flex justify-between">
                        <label for="created_at" class="text-gray-700 font-medium">Joined</label>
                        <div class="text-gray-800">{{ $user->created_at->format('F j, Y') }}</div>
                    </div>
                </div>

                <!-- Buttons Section -->
                <div class="mt-8 flex justify-between gap-4">
                    <a href="{{ route('dashboard') }}"
                        class="w-full md:w-auto bg-gray-300 text-gray-700 px-6 py-3 rounded-lg text-center hover:bg-gray-400 transition duration-300 ease-in-out">
                        Back to Dashboard
                    </a>
                    <a href="{{ route('change-password.form') }}"
                        class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                        Change Password
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Function to preview the selected image
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                const preview = document.getElementById('profileImagePreview');
                preview.src = e.target.result; // Set the source to the selected file's data URL
            }

            if (file) {
                reader.readAsDataURL(file); // Read the file as a Data URL
            } else {
                // If no file is selected, set the default image again
                document.getElementById('profileImagePreview').src =
                    '{{ asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png')) }}';
            }
        }

        // Enable/Disable update profile button based on file input
        document.getElementById('profile_image').addEventListener('change', function() {
            const updateProfileBtn = document.getElementById('updateProfileBtn');

            if (this.files && this.files[0]) {
                updateProfileBtn.disabled = false; // Enable button
            } else {
                updateProfileBtn.disabled = true; // Disable button if no file is selected
            }
        });

        // JavaScript for toggling mobile number visibility
        document.getElementById("toggleMobileNumber").addEventListener("click", function() {
            var maskedNumber = document.getElementById("maskedNumber");
            var fullNumber = document.getElementById("fullNumber");

            // Toggle visibility of the full mobile number
            if (fullNumber.style.display === "none") {
                fullNumber.style.display = "inline"; // Show full number
                maskedNumber.style.display = "none"; // Hide masked number
            } else {
                fullNumber.style.display = "none"; // Hide full number
                maskedNumber.style.display = "inline"; // Show masked number
            }
        });

        // JavaScript for toggling email visibility
        document.getElementById("toggleEmail").addEventListener("click", function() {
            var maskedEmail = document.getElementById("maskedEmail");
            var fullEmail = document.getElementById("fullEmail");

            // Toggle visibility of the full email
            if (fullEmail.style.display === "none") {
                fullEmail.style.display = "inline"; // Show full email
                maskedEmail.style.display = "none"; // Hide masked email
            } else {
                fullEmail.style.display = "none"; // Hide full email
                maskedEmail.style.display = "inline"; // Show masked email
            }
        });
</script>
@endsection