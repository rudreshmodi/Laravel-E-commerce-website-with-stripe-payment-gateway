@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Products in Subcategory: {{ $subcategory->name }}</h1>

        @if ($products->isEmpty())
            <div class="alert alert-warning">
                No products found for this subcategory.
            </div>
        @else
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($products as $product)
                            <tr>
                                <td>{{ $product->id }}</td>
                                <td>{{ $product->name }}</td>
                                <td>{{ $product->description }}</td>
                                <td>{{ $product->price }}</td>
                                <td>{{ ucfirst($product->status) }}</td>
                                <td>{{ $product->created_at->format('M j, Y') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <!-- Pagination Links -->
                {{ $products->links() }}
            </div>
        @endif
    </div>
@endsection
