@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-8">
        <!-- Breadcrumb Navigation -->
        <nav class="flex text-md text-gray-600 mb-4 items-center justify-between">
            <div class="flex items-center">
                <a href="{{ route('dashboard') }}"
                    class="hover:text-blue-500 flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <a href="{{ route('order.index') }}"
                    class="hover:text-blue-500 flex items-center {{ Request::is('orders') || Request::is('orders/*') ? 'text-blue-500' : '' }}">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Orders</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full text-blue-500">Order #{{ $order->id }}</span>
            </div>

            <!-- Back to Orders Button -->
            <div class="flex items-center">
                <a href="{{ route('order.index') }}"
                    class="bg-blue-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300">
                    Back to Orders
                </a>
            </div>
        </nav>

        <!-- Order Details -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-2xl font-semibold text-gray-800 mb-4">Order #{{ $order->id }}</h2>

            <div class="mb-4">
                <strong class="text-gray-600">Order Date:</strong>
                <span>{{ $order->created_at->format('F j, Y, g:i a') }}</span>
            </div>
            <div class="mb-4">
                <strong class="text-gray-600">Status:</strong>
                <span class="text-blue-500">{{ ucfirst($order->status) }}</span>
            </div>
            <div class="mb-4">
                <strong class="text-gray-600">Total:</strong>
                <span class="text-xl font-semibold">${{ number_format($order->total, 2) }}</span>
            </div>

            <!-- Order Items -->
            <h3 class="text-xl font-semibold text-gray-800 mb-4">Items</h3>
            <div class="space-y-4">
                @foreach ($order as $orders)
                    <div class="flex items-center justify-between border-b pb-4">
                        <!-- Product Info -->
                        <div class="flex items-center">
                            <img src="{{ $orders->order_images ? asset('storage/' . $orders->order_images) : asset('images/placeholder.png') }}"
                                alt="{{ $orders->product->name }}" class="w-16 h-16 object-cover rounded-md mr-4">
                            <div>
                                <h4 class="text-lg font-semibold text-gray-800">{{ $orders->product->name }}</h4>
                                <p class="text-sm text-gray-600">{{ $orders->product->description }}</p>
                            </div>
                        </div>
                        <!-- Order Details -->
                        <div class="text-right">
                            <p class="text-gray-600">Quantity: {{ $item->order_items }}</p>
                            <p class="text-gray-600">Price: ${{ number_format($item->order_prices, 2) }}</p>
                            <p class="text-gray-800 font-semibold">Subtotal:
                                ${{ number_format($item->order_prices * $item->order_quantities, 2) }}</p>
                        </div>
                    </div>
                @endforeach

                <!-- Order Summary -->
                <div class="flex justify-between mt-4">
                    <div>
                        <p class="text-gray-800">Order ID: {{ $order->id }}</p>
                        <p class="text-gray-600">User ID: {{ $order->user_id }}</p>
                        <p class="text-gray-600">Status: {{ ucfirst($order->status) }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-xl font-semibold text-gray-800">Total: ${{ number_format($order->total, 2) }}</p>
                    </div>
                </div>

            </div>
        </div>

        <!-- Order Images -->
        @if ($order->order_images->count())
            <h3 class="text-xl font-semibold text-gray-800 mb-4">Order Images</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                @foreach ($order->order_images as $image)
                    <div class="bg-gray-100 rounded-lg shadow-md overflow-hidden">
                        <img src="{{ asset('storage/' . $image->path) }}" alt="Order Image"
                            class="w-full h-48 object-cover">
                    </div>
                @endforeach
            </div>
        @endif

        <!-- Order Status Change (Optional) -->
        @if ($order->status != 'completed')
            <div class="mt-6">
                <form action="{{ route('orders.updateStatus', $order->id) }}" method="POST" class="flex items-center">
                    @csrf
                    @method('PUT')
                    <select name="status" class="bg-gray-100 border border-gray-300 rounded-lg px-4 py-2">
                        <option value="pending" {{ $order->status == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="shipped" {{ $order->status == 'shipped' ? 'selected' : '' }}>Shipped</option>
                        <option value="completed" {{ $order->status == 'completed' ? 'selected' : '' }}>Completed</option>
                    </select>
                    <button type="submit"
                        class="bg-blue-500 text-white px-4 py-2 ml-4 rounded-lg shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300">
                        Update Status
                    </button>
                </form>
            </div>
        @endif

        <!-- Success and Error Toasts -->
        @if (session('success'))
            <div id="successToast"
                class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                <i class="fas fa-check-circle text-white text-2xl"></i>
                <span>{{ session('success') }}</span>
            </div>

            <script>
                setTimeout(() => {
                    document.querySelector('#successToast').style.display = 'none';
                }, 4000);
            </script>
        @endif

        @if (session('error'))
            <div id="errorToast"
                class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                <i class="fas fa-times-circle text-white text-2xl"></i>
                <span>{{ session('error') }}</span>
            </div>

            <script>
                setTimeout(() => {
                    document.querySelector('#errorToast').style.display = 'none';
                }, 4000);
            </script>
        @endif
    </div>
@endsection
