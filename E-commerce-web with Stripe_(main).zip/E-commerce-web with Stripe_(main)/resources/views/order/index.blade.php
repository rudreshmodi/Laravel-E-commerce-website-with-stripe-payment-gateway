@extends('layouts.app')

@section('content')
<div class="container mx-auto text-sm">
    <!-- Breadcrumb Navigation -->
    <nav class="flex text-md text-gray-600 mb-4 items-center justify-between">
        <div class="flex items-center">
            <a href="{{ route('dashboard') }}"
                class="hover:text-blue-500 flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
            </a>
            <span class="mx-2 text-xs">/</span>
            <a href="{{ route('order.index') }}"
                class="hover:text-blue-500 flex items-center {{ Request::is('orders') || Request::is('orders/*') ? 'text-blue-500' : '' }}">
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Orders</span>
            </a>
        </div>

    </nav>

    <!-- Filter Bar -->
    <form action="{{ route('order.index') }}" method="GET"
        class="flex justify-between items-center mb-6 bg-gray-50 p-4 rounded-lg shadow-md">
        <div class="flex space-x-2 text-sm">
            <!-- Search Input (Optional) -->
            <input type="text" name="search" placeholder="Search by order ID or user..."
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400">

            <!-- Status Dropdown (Optional) -->
            <select name="status"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400">
                <option value="">Status</option>
                <option value="Paid">Paid</option>
                <option value="Cash on Delivery">Cash on Delivery</option>
                <option value="Cancelled">Cancelled</option>
            </select>

            <!-- Apply Filters Button -->
            <button type="submit"
                class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300">
                Apply Filters
            </button>

            <!-- Reset Button -->
            <a href="{{ route('order.index') }}"
                class="bg-gray-800 text-white px-6 py-3 rounded-full shadow-lg hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 flex items-center justify-center">
                <i class="fas fa-undo"></i>
            </a>
        </div>
    </form>

    <!-- Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">User</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Order_price</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Status</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                @forelse ($orders as $order)
                <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                    <td class="px-6 py-4 text-sm text-gray-800">{{ $order->id }}</td>
                    <td class="px-6 py-4 text-sm text-gray-800">{{ $order->user->name }}</td>
                    {{-- <td class="px-6 py-4 text-sm text-gray-800">{{ $order->products->name }}</td> --}}
                    <td class="px-6 py-4 text-sm text-gray-800">${{ number_format($order->total, 2) }}</td>
                    <td class="px-6 py-4 text-sm text-gray-800">
                        <span class="px-4 py-2 rounded-full    {{ $order->status === 'paid'
                                        ? 'text-green-500 bg-white'
                                        : ($order->status === 'pending'
                                            ? 'bg-yellow-500 text-white'
                                            : ($order->status === 'cash on delivery'
                                                ? 'text-green-500 bg-white'
                                                : 'text-gray-500 bg-white')) }}">
                            {{ ucfirst($order->status) }}
                        </span>

                    </td>
                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-4">
                            <a href="{{ route('order.show', $order) }}"
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300">
                                <i class="fas fa-eye"></i>
                            </a>
                            {{-- <a href="{{ route('order.edit', $order) }}"
                                class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300">
                                <i class="fas fa-edit"></i>
                            </a> --}}
                            <button type="button"
                                class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300"
                                onclick="confirmDelete({{ $order->id }})">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" class="px-6 py-4 text-center text-gray-500">No orders found.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $orders->links() }}
        <!-- Pagination Links -->
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Are you sure you want to delete this order?</h3>
        <form id="deleteForm" method="POST">
            @csrf
            @method('DELETE')
            <div class="flex justify-end space-x-4">
                <button type="button" onclick="closeModal()"
                    class="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 transition duration-300">
                    Cancel
                </button>
                <button type="submit"
                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300">
                    Delete
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function confirmDelete(orderId) {
            const deleteModal = document.getElementById('deleteModal');
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/orders/${orderId}`;
            deleteModal.classList.remove('hidden');
        }

        function closeModal() {
            const deleteModal = document.getElementById('deleteModal');
            deleteModal.classList.add('hidden');
        }
</script>
@if (session('success'))
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span>{{ session('success') }}</span>
</div>

<script>
    setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
</script>
@endif

<!-- Error Toast -->
@if (session('error'))
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span>{{ session('error') }}</span>
</div>

<script>
    setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
</script>
@endif
@endsection